#!/usr/bin/env python3
"""
Login server for "Seal II". Two pages only:
  GET  /login    - sign-in form
  POST /login    - issues a session cookie
  GET  /content  - the gated page (serves content.html only to a privileged session)

The cookie is NOT a JWT. It is a hand-rolled scheme:

    session = base64( data ) + "." + hex( SHA256( SECRET || data ) )

where `data` is a pipe-delimited field string. This "looks like" a MAC
(a secret-keyed hash guarding tamper-evident data) but SHA-256 is a
Merkle-Damgard hash, so anyone who has ONE valid (data, sig) pair can
compute SHA256(SECRET || data || glue_padding || anything_else) without
ever learning SECRET. That is a hash length-extension attack.

This file is the deployed challenge backend. It is not meant to be
handed to players -- see WRITEUP.md for the full solve.
"""
import hashlib
import http.cookies
import os
import random
import struct
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "4002"))

# --- secret: random length in [8,32], never logged, never exposed anywhere ---
SECRET = os.urandom(random.randint(8, 32))

# Field that grants access. Buried among decoys in the wire format below.
PRIV_KEY = b"x"
PRIV_ADMIN = b"9"

_next_uid = [1000]


def sign(data: bytes) -> str:
    return hashlib.sha256(SECRET + data).hexdigest()


def verify(data: bytes, sig_hex: str) -> bool:
    # Constant-time comparison of the *digest* -- deliberately realistic:
    # a developer careful enough to avoid a timing leak on the comparison
    # can still miss the length-extension flaw in the construction itself.
    import hmac
    try:
        expected = bytes.fromhex(sign(data))
        got = bytes.fromhex(sig_hex)
    except ValueError:
        return False
    return hmac.compare_digest(expected, got)


def make_data(uid: int, usr: str) -> bytes:
    # Pipe-delimited, last-key-wins parsing (see parse_data). Decoy fields
    # (chk, flags) are inert. The real gate is `x`; everything else is noise.
    usr_safe = usr.replace("|", "_").replace("=", "_")[:32]
    nc = os.urandom(4).hex()
    return (
        f"v=1|uid={uid}|usr={usr_safe}|iat={int(time.time())}|"
        f"nc={nc}|chk=00|flags=0000|x=1"
    ).encode("utf-8")


def parse_data(data: bytes) -> dict:
    """Deliberately naive: split on '|', then '=', last occurrence of a
    key wins. This is what makes an *appended* field override an earlier
    one -- the entire point of the length-extension trick."""
    fields = {}
    for chunk in data.split(b"|"):
        if b"=" not in chunk:
            continue
        k, _, v = chunk.partition(b"=")
        fields[k] = v
    return fields


def is_admin(data: bytes) -> bool:
    return parse_data(data).get(PRIV_KEY) == PRIV_ADMIN


def pack_cookie(data: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(data).decode() + "." + sign(data)


def unpack_cookie(value: str):
    import base64
    try:
        b64, sig_hex = value.rsplit(".", 1)
        data = base64.urlsafe_b64decode(b64 + "=" * (-len(b64) % 4))
    except Exception:
        return None
    if not verify(data, sig_hex):
        return None
    return data


LOGIN_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Seal II &middot; Sign in</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{{color-scheme:dark;--bg:#04050c;--fg:#eaf0ff;--dim:#8a93b8;--acc:#9cc4ff;--bad:#ff8d8d}}
*{{box-sizing:border-box}}
html,body{{height:100%;margin:0}}
body{{display:grid;place-items:center;color:var(--fg);font-family:'Cinzel',Georgia,serif;
  background:radial-gradient(60% 50% at 20% 25%,rgba(70,60,160,.25),transparent),
             radial-gradient(55% 45% at 80% 75%,rgba(24,97,153,.22),transparent),var(--bg)}}
.card{{width:min(92vw,380px);padding:28px;border-radius:16px;
  background:linear-gradient(160deg,rgba(24,30,66,.9),rgba(10,13,30,.92));
  border:1px solid rgba(156,196,255,.35);box-shadow:0 0 40px rgba(110,150,255,.25)}}
h1{{margin:0 0 6px;font-size:18px;letter-spacing:.18em;text-transform:uppercase}}
p{{margin:0 0 18px;color:var(--dim);font-family:Georgia,serif;font-size:13px;line-height:1.6}}
label{{display:block;margin:0 0 6px;font-size:12px;color:var(--dim);font-family:Georgia,serif}}
input{{width:100%;padding:11px 12px;margin-bottom:14px;border-radius:8px;border:1px solid rgba(156,196,255,.35);
  background:rgba(3,5,14,.8);color:var(--fg);font:14px ui-monospace,Menlo,Consolas,monospace}}
input:focus{{outline:none;border-color:var(--acc);box-shadow:0 0 12px rgba(156,196,255,.4)}}
button{{width:100%;padding:11px;border-radius:8px;border:1px solid rgba(156,196,255,.4);
  background:rgba(40,56,130,.5);color:var(--fg);font:inherit;font-size:13px;letter-spacing:.14em;
  text-transform:uppercase;cursor:pointer}}
button:hover{{background:rgba(70,95,200,.6)}}
.msg{{min-height:1.2em;margin-top:10px;font-size:12px;color:var(--bad);font-family:Georgia,serif}}
</style></head><body>
<form class="card" method="post" action="/login">
  <h1>ECHO - NOTEBOOK</h1>
  <p>Only i can access my notebook and noone else. Can You!</p>
  <label for="u">Name</label>
  <input id="u" name="username" autocomplete="off" spellcheck="false" required>
  <button type="submit">Enter</button>
  <div class="msg">{msg}</div>
</form></body></html>"""

LOCKED_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Seal II &middot; Locked</title>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{{color-scheme:dark;--bg:#04050c;--fg:#eaf0ff;--dim:#8a93b8;--acc:#9cc4ff}}
*{{box-sizing:border-box}}html,body{{height:100%;margin:0}}
body{{display:grid;place-items:center;color:var(--fg);font-family:'Cinzel',Georgia,serif;text-align:center;
  background:radial-gradient(60% 50% at 20% 25%,rgba(70,60,160,.25),transparent),
             radial-gradient(55% 45% at 80% 75%,rgba(24,97,153,.22),transparent),var(--bg)}}
.card{{width:min(92vw,380px);padding:28px;border-radius:16px;
  background:linear-gradient(160deg,rgba(24,30,66,.9),rgba(10,13,30,.92));
  border:1px solid rgba(156,196,255,.35);box-shadow:0 0 40px rgba(110,150,255,.25)}}
h1{{margin:0 0 10px;font-size:18px;letter-spacing:.18em;text-transform:uppercase}}
p{{margin:0;color:var(--dim);font-family:Georgia,serif;font-size:13px;line-height:1.7}}
code{{color:var(--acc)}}
</style></head><body>
<div class="card"><h1>Sealed</h1>
<p>You hold a session, {who}, but it carries no weight here.<br>
The gate answers only to those it trusts completely.</p></div>
</body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "SealII/1.0"

    def _cookie(self):
        raw = self.headers.get("Cookie", "")
        jar = http.cookies.SimpleCookie()
        jar.load(raw)
        if "session" in jar:
            return unpack_cookie(jar["session"].value)
        return None

    def _send(self, code, body: bytes, ctype="text/html; charset=utf-8", set_cookie=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if set_cookie:
            self.send_header("Set-Cookie", set_cookie)
        self.end_headers()
        self.wfile.write(body)

    def _redirect(self, path):
        self.send_response(303)
        self.send_header("Location", path)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.path in ("/", ""):
            return self._redirect("/content")
        if self.path == "/login":
            return self._send(200, LOGIN_PAGE.format(msg="").encode())
        if self.path == "/content":
            data = self._cookie()
            if data is None:
                return self._redirect("/login")
            if is_admin(data):
                try:
                    with open(os.path.join(HERE, "content.html"), "rb") as f:
                        return self._send(200, f.read())
                except FileNotFoundError:
                    return self._send(500, b"content.html missing")
            who = parse_data(data).get(b"usr", b"stranger").decode("utf-8", "replace")
            return self._send(403, LOCKED_PAGE.format(who=who).encode())
        self._send(404, b"not found")

    def do_POST(self):
        if self.path != "/login":
            return self._send(404, b"not found")
        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length) if length else b""
        fields = parse_qs(body.decode("utf-8", "replace"))
        username = (fields.get("username", [""])[0] or "stranger").strip()
        if not username:
            return self._send(400, LOGIN_PAGE.format(msg="A name is required.").encode())
        _next_uid[0] += 1
        data = make_data(_next_uid[0], username)
        cookie = f"session={pack_cookie(data)}; Path=/; HttpOnly; SameSite=Lax"
        self.send_response(303)
        self.send_header("Location", "/content")
        self.send_header("Set-Cookie", cookie)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def log_message(self, fmt, *args):
        pass  # keep container logs quiet; no secrets are ever logged anyway


if __name__ == "__main__":
    print(f"Seal II listening on 0.0.0.0:{PORT}")
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
