# Seal II — solution writeup (operator reference)

**This file is for you, not for players.** It explains exactly how `server.py`

If you want to sanity-check it yourself:
```bash
python3 server.py &                                   # starts on :4002
curl -s -c jar.txt -X POST http://127.0.0.1:4002/login -d "username=astra"
COOKIE=$(python3 -c "
with open('jar.txt') as f:
    for line in f:
        if line.startswith('#HttpOnly_'):
            print(line.strip().split()[-1])
")
python3 solve_forge.py http://127.0.0.1:4002 "$COOKIE"
```

## 1. What's actually deployed

Two pages:
- `GET /login`, `POST /login` — takes any username, no password, and issues a
  session cookie for an ordinary (non-admin) user.
- `GET /content` — serves `content.html` (your real story/flag page) if the
  session is privileged; otherwise returns a locked teaser.

## 2. The cookie format

```
session = base64url( data ) + "." + hex( SHA256( SECRET || data ) )
```

`data` is a pipe-delimited string, e.g.:
```
v=1|uid=1001|usr=astra|iat=1793943965|nc=f6ea7e89|chk=00|flags=0000|x=1
```

- `chk` and `flags` are **decoys** — always fixed values, never read anywhere.
- `x` is the real privilege field. `x=1` is an ordinary session; the server
  grants `/content` only when `x=9`.
- The server parses `data` by splitting on `|` then `=`, filling a dict —
  **the last occurrence of a key wins.** That single design choice is what
  makes the attack below work: an attacker doesn't need to *replace* `x=1`,
  only to *append* another `x=9` after it.

This isn't a JWT (no `{"alg":...}` header, nothing that screams "forge me a
different algorithm"), so it doesn't pattern-match to a named, Googleable CVE.
It's a bespoke "secret-prefix hash" scheme, which is exactly the class of bug
that's vulnerable to hash length-extension.

## 3. The actual vulnerability: SHA-256 length extension

SHA-256 (like MD5 and SHA-1) is a **Merkle–Damgård** hash: it processes a
message in fixed-size blocks, carrying an internal state from one block to
the next, and the final digest *is* that internal state. This means:

> If you know `SHA256(secret || data)` and `len(secret)` (or just a guess at
> it), you can compute `SHA256(secret || data || padding || anything)` for
> **any** `anything` you like — without ever knowing `secret`.

The digest hex string you already have *is* the hash function's internal
state after processing `secret || data`. You can resume the compression
function from that state and feed it more blocks. The `padding` piece is the
deterministic bit-padding SHA-256 always inserts before the length suffix —
it has to be replayed exactly (its value is a pure function of
`len(secret) + len(data)`), which is why `secret_len` matters even though
`secret` itself never needs to be known.

This is **not** the same bug as "weak secret" or "guessable password" — a
secret of *any* strength is vulnerable if it's used as `H(secret || data)`
instead of a real MAC (HMAC, or signing with it as an HMAC *key* rather than
a *prefix*). That distinction is the whole point of the challenge.

## 4. Why the unknown secret length doesn't block it

`SECRET = os.urandom(random.randint(8, 32))` — 8 to 32 bytes, chosen fresh
each time the server starts, never logged or exposed anywhere. There's no
leak to read it from. But the range is small enough to brute-force *blindly*:
try every length from 8 to 32, forge a candidate cookie for each, and ask the
live server whether it's accepted. At most 25 live requests. The player
doesn't need to know the secret — only its length, and even that they can
find by trial.

## 5. The forge, step by step

1. **Capture a real cookie.** Log in with any username; note the cookie's
   `data.sig` value.
2. **Recover the raw bytes.** Base64-decode the part before the dot — this
   is `data`, the literal pipe-delimited string.
3. **Pick the append.** The goal is to make `x=9` the last occurrence of `x`,
   so append `b"|x=9"`.
4. **For each candidate `secret_len` in 8..32:**
   a. Reconstruct the SHA-256 internal state from the captured hex digest
      (it's just 8 big-endian 32-bit words).
   b. Compute the SHA-256 padding that *would have been* appended after
      `secret_len + len(data)` bytes (the "glue").
   c. Resume SHA-256 compression from that state, feeding it
      `b"|x=9" + <new padding based on the new total length>`.
   d. The result is a new valid digest for `secret || data || glue || "|x=9"`
      — call the new data (`data || glue || "|x=9"`) `new_data`.
   e. Base64url-encode `new_data`, append `.` and the new hex digest, send it
      as the `session` cookie to `/content`.
   f. If the server returns `200` (real content, not the `303` redirect to
      `/login` that a bad signature produces), that `secret_len` was right.
5. **Done.** The accepted cookie's `data` now parses as `x=9` last, the
   server's own "last key wins" logic treats the session as privileged, and
   `/content` returns the real page.

A full, tested implementation of steps 4a–4f is in `solve_forge.py` in this
folder (pure Python, no `hashpumpy`/`hlextend`, so there's nothing for a
player to just `pip install` and recognize by name). Example real output
against this server:

```
[   ] secret_len= 8  status=303
[   ] secret_len= 9  status=303
[OK ] secret_len=10  status=200
[+] forged with secret_len=10
```

## 6. Why this resists "ask an AI"

- There's no algorithm-name shortcut (no `"alg":"RS256"` field, no JWT
  library) for an AI to pattern-match against and hand back a known CVE.
- An AI can explain length-extension *in the abstract* (it's a real,
  documented technique), but turning that into a *working forgery against
  this specific server* requires: correctly reverse-engineering the exact
  byte layout of `data` (including ignoring the two decoy fields), writing or
  sourcing a correct SHA-256-continuation implementation, and iterating the
  unknown secret length against the *live* server — three separate things
  that all have to be right simultaneously, with no error message
  distinguishing "wrong secret length" from "wrong byte layout."
- A single off-by-one in the padding math, or signing/encoding the data with
  the wrong byte sequence, produces a cookie that's silently rejected
  (`303`) with no diagnostic. There's no partial credit.

## 7. If you want it even harder later

- Shrink the decoys' plausibility further (more of them, or give one a
  believable-but-irrelevant name like `role` while the real gate is the
  unnamed `x`).
- Increase the secret length ceiling (e.g. 8–64) — linear cost to the brute
  force, no change in technique.
- Rate-limit `/content` per IP to turn blind brute force into a patience
  test (be aware this also slows down legitimate verification/testing).

## 8. Fix, for your own notes

Don't build a MAC as `H(secret || data)`. Use `HMAC-SHA256(key=secret,
msg=data)` — HMAC's nested construction is specifically designed to be
immune to length extension, unlike a bare hash with a secret prefix.
