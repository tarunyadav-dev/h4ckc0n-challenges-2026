#!/usr/bin/env python3
"""
Reference solver for Seal II. Pure Python, no third-party libraries
(no hashpumpy/hlextend) -- implements the SHA-256 compression function
by hand so a hash length-extension attack can continue a digest without
ever knowing the secret.

Usage:
    python3 solve_forge.py <base_url>                 # logs in itself, then forges
    python3 solve_forge.py <base_url> --cookie "<value>"  # use a cookie you captured

<base_url> example: http://localhost:4002

For --cookie, paste ONLY the session value: the part that looks like
  <base64>.<64 hex chars>
Do NOT paste the whole "Set-Cookie: session=...; Path=/; HttpOnly" line --
this script strips a leading "session=" and a trailing "; ..." for you if
you do, but the safest input is just the base64.hex part by itself.

This is the OPERATOR'S reference solution (for testing/verifying the
challenge), not something meant to be handed to players. See WRITEUP.md.
"""
import argparse
import base64
import http.client
import re
import struct
import sys
import urllib.parse
import urllib.request

K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]
MASK = 0xFFFFFFFF


def rotr(x, n):
    return ((x >> n) | (x << (32 - n))) & MASK


def compress(state, block):
    w = list(struct.unpack(">16L", block)) + [0] * 48
    for i in range(16, 64):
        s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
        s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) & MASK
    a, b, c, d, e, f, g, h = state
    for i in range(64):
        S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
        ch = (e & f) ^ (~e & g)
        t1 = (h + S1 + ch + K[i] + w[i]) & MASK
        S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        t2 = (S0 + maj) & MASK
        h, g, f, e = g, f, e, (d + t1) & MASK
        d, c, b, a = c, b, a, (t1 + t2) & MASK
    return [(x + y) & MASK for x, y in zip(state, [a, b, c, d, e, f, g, h])]


def sha256_padding(total_len_bytes):
    ml = total_len_bytes * 8
    pad = b"\x80"
    pad += b"\x00" * ((56 - (total_len_bytes + 1) % 64) % 64)
    pad += struct.pack(">Q", ml)
    return pad


def length_extend(orig_sig_hex, orig_data, secret_len, append):
    """Given SHA256(secret||orig_data) = orig_sig_hex, and a GUESSED
    secret_len, compute SHA256(secret || orig_data || glue || append)
    without ever knowing `secret`. Returns (new_data, new_sig_hex)."""
    state = list(struct.unpack(">8L", bytes.fromhex(orig_sig_hex)))
    total_before = secret_len + len(orig_data)
    glue = sha256_padding(total_before)
    total_after = total_before + len(glue) + len(append)
    tail = append + sha256_padding(total_after)
    for i in range(0, len(tail), 64):
        state = compress(state, tail[i : i + 64])
    new_sig = b"".join(struct.pack(">L", x) for x in state).hex()
    new_data = orig_data + glue + append
    return new_data, new_sig


def b64_nopad(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


class NoRedirect(urllib.request.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response  # don't let urllib chase the 303 to /login on a failed forge
    https_response = http_response


_opener = urllib.request.build_opener(NoRedirect)


def fetch_content(base_url, cookie_value):
    req = urllib.request.Request(base_url.rstrip("/") + "/content", headers={"Cookie": f"session={cookie_value}"})
    with _opener.open(req, timeout=5) as r:
        return r.status, r.read()


COOKIE_RE = re.compile(r"([A-Za-z0-9_-]+=*\.[0-9a-fA-F]{64})")


def clean_cookie(raw: str) -> str:
    """Forgiving extractor: works whether the user pasted just the value,
    a full 'Set-Cookie: session=...; Path=/...' header, or 'session=...'
    with trailing attributes. Pulls out the <base64>.<64-hex> pattern."""
    raw = raw.strip()
    m = COOKIE_RE.search(raw)
    if not m:
        print("[-] couldn't find a <base64>.<64 hex chars> pattern in that value.")
        print(f"    you gave: {raw!r}")
        print("    paste ONLY the session cookie's value (no 'Set-Cookie:', no 'session=',")
        print("    no trailing '; Path=/; HttpOnly...').")
        sys.exit(1)
    return m.group(1)


def login(base_url: str, username: str) -> str:
    """Logs in exactly like a browser submitting the form, and returns the
    raw session cookie value from the Set-Cookie response header."""
    url = base_url.rstrip("/") + "/login"
    body = urllib.parse.urlencode({"username": username}).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    try:
        resp = _opener.open(req, timeout=5)
    except Exception as e:
        print(f"[-] could not reach {url}: {e}")
        print("    is the server actually running and is this the right host/port?")
        print("    (check: docker compose ps   and   docker compose logs)")
        sys.exit(1)
    set_cookie = resp.headers.get("Set-Cookie")
    if not set_cookie:
        print(f"[-] logged in (status {resp.status}) but got no Set-Cookie header back.")
        sys.exit(1)
    return clean_cookie(set_cookie)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("base_url", help="e.g. http://localhost:4002")
    ap.add_argument("--cookie", help="a captured session cookie value; if omitted, this script logs in itself")
    ap.add_argument("--username", default="forger", help="username to use when logging in automatically")
    args = ap.parse_args()

    if args.cookie:
        cookie = clean_cookie(args.cookie)
        print(f"[*] using provided cookie")
    else:
        print(f"[*] no --cookie given: logging in as {args.username!r} at {args.base_url}/login ...")
        cookie = login(args.base_url, args.username)
        print(f"[*] got a fresh session cookie from the server")

    b64_part, sig_hex = cookie.rsplit(".", 1)
    try:
        orig_data = base64.urlsafe_b64decode(b64_part + "=" * (-len(b64_part) % 4))
        bytes.fromhex(sig_hex)  # validate early, fail with a clear message instead of a traceback later
    except Exception as e:
        print(f"[-] that cookie didn't decode as expected: {e}")
        print(f"    base64 part: {b64_part!r}")
        print(f"    sig part   : {sig_hex!r}")
        sys.exit(1)

    print(f"[*] captured data: {orig_data!r}")
    print(f"[*] captured sig : {sig_hex}")

    # Sanity check: does this cookie even verify as-is? If not, it's stale
    # (e.g. the server restarted and rotated its secret since this cookie
    # was issued) and NO forgery built on it can ever work.
    try:
        status, _ = fetch_content(args.base_url, cookie)
        print(f"[*] this cookie as-is -> status {status} ({'accepted, but not yet admin' if status == 403 else 'unexpected'})")
    except Exception as e:
        print(f"[-] could not reach {args.base_url}: {e}")
        sys.exit(1)

    append = b"|x=9"  # the privilege field, forced to admin, appended last so it wins
    for secret_len in range(8, 33):  # bounded, unknown secret length -- no oracle, just try them all
        new_data, new_sig = length_extend(sig_hex, orig_data, secret_len, append)
        forged_cookie = b64_nopad(new_data) + "." + new_sig
        try:
            status, body = fetch_content(args.base_url, forged_cookie)
        except Exception as e:
            print(f"[-] request failed for secret_len={secret_len}: {e}")
            continue
        mark = "OK " if status == 200 else "   "
        print(f"[{mark}] secret_len={secret_len:>2}  status={status}")
        if status == 200:
            print(f"\n[+] forged with secret_len={secret_len}")
            print(f"[+] forged cookie: {forged_cookie}")
            print("\n--- server response ---")
            print(body.decode("utf-8", "replace"))
            return
    print("[-] no secret length in range (8-32) worked.")
    print("    if the sanity-check status above was NOT 403, the cookie itself is stale")
    print("    (likely the server restarted since it was issued) -- log in again and retry.")


if __name__ == "__main__":
    main()