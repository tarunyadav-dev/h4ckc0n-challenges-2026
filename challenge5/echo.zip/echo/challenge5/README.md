# ECHO — Private Network

A lightweight CTF landing page with a pattern gate, animated three-system interface, secret verification, and final flag reveal.

## Runtime design

- Next.js standalone production server on port `3333`.
- Three external challenge systems are linked on ports `4001`, `4002`, and `4003`.
- No database, ORM, migrations, persistent volume, player history, or submission tracking.
- The pattern gate uses a signed, expiring HttpOnly cookie. The signing key is configured with `SESSION_SECRET`; no session records are stored.
- Challenge completion is held only in browser memory. Refreshing the page resets it.
- Challenge secrets are verified server-side. The final flag endpoint validates all three proofs together before returning the flag.
- Submission attempts are not rate-limited or recorded.

## Configure

```bash
cp .env.example .env.local
```

Set a strong random `SESSION_SECRET` (at least 24 characters), the private pattern, all three challenge secrets, and the final flag. For local HTTP testing keep `COOKIE_SECURE=false`; set `COOKIE_SECURE=true` behind HTTPS in production. Keep `.env.local` private and never commit it.

Generate a signing key with:

```bash
openssl rand -base64 48
```

## Build and run

This folder contains the challenge application and its Dockerfile. The Compose configuration is maintained centrally at the CTF project root, not inside this challenge folder.

From the CTF project root, the central Compose file should build this service using `./challenge5` (or the actual folder name you assign to this infrastructure) as its build context and publish container port `3333`.

For an isolated local test from this folder:

```bash
docker build -t echo-infra .
docker run --rm --env-file .env.local -p 3333:3333 echo-infra
```

The site is available on port `3333`. The three linked systems must separately be reachable by visitors on ports `4001`, `4002`, and `4003`. Links inherit the hostname and protocol of the ECHO page.

There is no persistent volume. A container restart does not restore visitor progress.

## Image optimization

The Dockerfile uses three stages:
1. Install dependencies.
2. Build Next.js.
3. Copy only Next.js standalone output and static assets into a clean Alpine runtime image.

Development dependencies, source tests, documentation, Prisma, SQLite, and build caches are not copied into the final image.

Check the resulting image size:

```bash
docker image ls the-mirror-investigation
```

## Security notes

- Run behind HTTPS in production.
- Keep `.env.local` out of source control and the Docker build context.
- The pattern gate is server-checked and protected by a signed, expiring HttpOnly cookie.
- Challenge secrets and the final flag are server-only environment variables.
- The app intentionally has no submission rate limiting or attempt tracking, as requested. This permits unlimited guessing; use strong, high-entropy challenge secrets.
- Apply container-level hardening in the central Compose configuration: drop unnecessary Linux capabilities, prevent privilege escalation, use a read-only root filesystem where compatible, and provide temporary writable filesystems.
