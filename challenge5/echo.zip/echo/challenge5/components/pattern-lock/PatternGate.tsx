"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { post } from "../../lib/client";

const HIT = 7; // fixed hit radius (dot spacing is 20, so zones never overlap)
const pos = (n: number) => ({ x: 10 + ((n - 1) % 5) * 20, y: 10 + Math.floor((n - 1) / 5) * 20 });
type Pt = { x: number; y: number };

export default function PatternGate() {
  const router = useRouter();
  const svg = useRef<SVGSVGElement>(null);
  const seqRef = useRef<number[]>([]);
  const last = useRef<Pt | null>(null);
  const [seq, setSeq] = useState<number[]>([]);
  const [cur, setCur] = useState<Pt | null>(null);
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [text, setText] = useState("");

  const local = (e: React.PointerEvent): Pt => {
    const r = svg.current!.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 };
  };
  const hit = (p: Pt) => {
    for (let n = 1; n <= 25; n++) if (Math.hypot(pos(n).x - p.x, pos(n).y - p.y) <= HIT) return n;
    return 0;
  };
  const push = (n: number) => {
    if (n && !seqRef.current.includes(n)) {
      seqRef.current = [...seqRef.current, n];
      setSeq(seqRef.current);
    }
  };
  // Sample along the pointer's path so fast swipes still select every dot they cross, in order.
  const sweep = (a: Pt, b: Pt) => {
    const steps = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 2));
    for (let i = 1; i <= steps; i++) push(hit({ x: a.x + ((b.x - a.x) * i) / steps, y: a.y + ((b.y - a.y) * i) / steps }));
  };

  async function submit(pattern: number[]) {
    if (busy || !pattern.length) return;
    setBusy(true);
    setMsg("");
    const r = await post("/api/auth/pattern", { pattern });
    if (r.status === 200) return router.refresh();
    setMsg(r.status === 0 ? "NETWORK UNAVAILABLE. CHECK YOUR CONNECTION." : "ACCESS DENIED.");
    setTimeout(() => {
      seqRef.current = [];
      setSeq([]);
      setBusy(false);
    }, 700);
  }

  const end = () => {
    if (!drag) return;
    setDrag(false);
    setCur(null);
    void submit(seqRef.current);
  };

  const pts = seq.map(pos);
  return (
    <div className="gate-box">
      <div className="gate-brand">ECHO <span>·</span> PRIVATE NETWORK</div>
      <div className="gate-heading">IDENTITY VERIFICATION</div>
      <div className="gate-subtitle">AWAITING AUTHENTICATION</div>
      <svg
        ref={svg}
        viewBox="0 0 100 100"
        className="lock-grid"
        aria-label="ECHO identity verification grid, five by five"
        onPointerDown={(e) => {
          if (busy) return;
          e.currentTarget.setPointerCapture(e.pointerId);
          seqRef.current = [];
          setSeq([]);
          setMsg("");
          const p = local(e);
          last.current = p;
          setDrag(true);
          setCur(p);
          push(hit(p));
        }}
        onPointerMove={(e) => {
          if (!drag || !last.current) return;
          const p = local(e);
          sweep(last.current, p);
          last.current = p;
          setCur(p);
        }}
        onPointerUp={end}
        onPointerCancel={() => {
          setDrag(false);
          setCur(null);
          seqRef.current = [];
          setSeq([]);
        }}
      >
        {pts.length > 0 && (
          <polyline className="trace" points={[...pts, ...(drag && cur ? [cur] : [])].map((p) => `${p.x},${p.y}`).join(" ")} />
        )}
        {Array.from({ length: 25 }, (_, i) => i + 1).map((n) => (
          <circle key={n} cx={pos(n).x} cy={pos(n).y} r={seq.includes(n) ? 3.2 : 2} className={seq.includes(n) ? "dot on" : "dot"} />
        ))}
      </svg>
      <p role="alert" className="msg">{msg}</p>
      <form
        className="kbd"
        onSubmit={(e) => {
          e.preventDefault();
          void submit(text.split(/[\s,]+/).filter(Boolean).map(Number));
        }}
      >
        <label htmlFor="seq">KEY SEQUENCE</label>
        <div>
          <input id="seq" value={text} onChange={(e) => setText(e.target.value)} inputMode="numeric" autoComplete="off" spellCheck={false} />
          <button type="submit" disabled={busy}>{busy ? "VERIFYING…" : "AUTHORIZE"}</button>
        </div>
      </form>
      <div className="gate-subtitle">IDENTITY VERIFICATION REQUIRED</div>
    </div>
  );
}
