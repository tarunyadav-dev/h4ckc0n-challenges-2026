import PatternGate from "../components/pattern-lock/PatternGate";
import Vault from "../components/vault-interface/Vault";
import { hasAccess } from "../lib/auth";
import { publicMeta } from "../lib/challenges";

export const dynamic = "force-dynamic";

export default async function Page() {
  if (!(await hasAccess())) return <main className="gate"><PatternGate /></main>;
  return <main><Vault meta={publicMeta()} initial={[]} /></main>;
}
