import { hasAccess } from "../../../../../lib/auth";
import { isId, secretMatches } from "../../../../../lib/challenges";
import { json, readJson, sameOrigin } from "../../../../../lib/security";
import { SecretBody } from "../../../../../lib/validation";

export async function POST(req: Request, ctx: { params: Promise<{ challengeId: string }> }) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  if (!(await hasAccess())) return json(401, { ok: false, error: "unauthorized" });
  const { challengeId } = await ctx.params;
  if (!isId(challengeId)) return json(404, { ok: false, error: "not_found" });

  const body = SecretBody.safeParse(await readJson(req));
  if (!body.success || !secretMatches(challengeId, body.data.secret)) {
    return json(401, { ok: false, error: "invalid" });
  }
  return json(200, { ok: true, challengeId });
}
