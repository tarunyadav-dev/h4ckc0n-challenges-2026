import { hasAccess } from "../../../lib/auth";
import { getEnv } from "../../../lib/env";
import { IDS, secretMatches } from "../../../lib/challenges";
import { json, readJson, sameOrigin } from "../../../lib/security";
import { ProofsBody } from "../../../lib/validation";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  if (!(await hasAccess())) return json(401, { ok: false, error: "unauthorized" });
  const body = ProofsBody.safeParse(await readJson(req));
  if (!body.success) return json(400, { ok: false, error: "invalid" });

  const valid = IDS.every((id, index) => secretMatches(id, body.data.secrets[index]));
  if (!valid) return json(403, { ok: false, error: "locked" });

  return json(200, { ok: true, flag: getEnv().FINAL_FLAG });
}
