import { NextResponse } from "next/server";
import { COOKIE, accessCookieOptions } from "../../../../lib/auth";
import { json, sameOrigin } from "../../../../lib/security";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const response = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  response.cookies.set(COOKIE, "", { ...accessCookieOptions(), maxAge: 0 });
  return response;
}
