import { NextResponse } from "next/server";
import { COOKIE, accessCookieOptions, createAccessToken } from "../../../../lib/auth";
import { getEnv } from "../../../../lib/env";
import { json, readJson, sameOrigin } from "../../../../lib/security";
import { PatternBody, patternMatches } from "../../../../lib/validation";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const body = PatternBody.safeParse(await readJson(req));
  if (!body.success || !patternMatches(body.data.pattern, getEnv().PATTERN_LOCK_SECRET)) {
    return json(401, { ok: false, error: "invalid" });
  }

  const response = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  response.cookies.set(COOKIE, createAccessToken(), accessCookieOptions());
  return response;
}
