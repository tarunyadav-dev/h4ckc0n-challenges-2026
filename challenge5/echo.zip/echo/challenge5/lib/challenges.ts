import { getEnv } from "./env";
import { safeEqual } from "./crypto";

export const IDS = ["c1", "c2", "c3"] as const;
export type Id = (typeof IDS)[number];
export const isId = (value: string): value is Id => (IDS as readonly string[]).includes(value);

const secretOf = (id: Id) => {
  const env = getEnv();
  return { c1: env.CHALLENGE_1_SECRET, c2: env.CHALLENGE_2_SECRET, c3: env.CHALLENGE_3_SECRET }[id];
};

export function secretMatches(id: Id, submitted: string) {
  return safeEqual(submitted, secretOf(id));
}

export function publicMeta() {
  return [
    { id: "c1" as const, tag: "01", title: "IDENTITY CACHE", desc: "The mirror and the archive disagree about the same envelope.", post: "The record holds. Nothing out of place.", path: "/challenge5.1/" },
    { id: "c2" as const, tag: "02", title: "NOTEBOOK", desc: "A signed record can still tell two different stories.", post: "Their doors are open. Just as planned.", path: "/challenge5.2/" },
    { id: "c3" as const, tag: "03", title: "DEVICE LINK", desc: "The collector kept the evidence. The clocks did not agree.", post: "The connection is mine now.", path: "/challenge5.3/" },
  ];
}
