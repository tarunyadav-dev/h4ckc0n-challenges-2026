import { z } from "zod";
import { safeEqual } from "./crypto";

export const PatternBody = z.object({
  pattern: z.array(z.number().int().min(1).max(25)).min(1).max(25),
}).strict().refine((body) => new Set(body.pattern).size === body.pattern.length);

export const SecretBody = z.object({ secret: z.string().min(1).max(256) }).strict();
export const ProofsBody = z.object({
  secrets: z.array(z.string().min(1).max(256)).length(3),
}).strict();

export const patternMatches = (input: number[], expected: number[]) =>
  input.length === expected.length && safeEqual(input.join(","), expected.join(","));
