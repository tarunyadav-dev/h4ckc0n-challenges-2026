import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { getEnv } from "./env";

export const COOKIE = "echo_access";
const ttlSeconds = 7 * 24 * 60 * 60;

function signature(payload: string) {
  return createHmac("sha256", getEnv().SESSION_SECRET).update(payload).digest("base64url");
}

export function createAccessToken() {
  const expires = Math.floor(Date.now() / 1000) + ttlSeconds;
  const payload = String(expires);
  return `${payload}.${signature(payload)}`;
}

export function isValidAccessToken(token: string | undefined) {
  if (!token || token.length > 256) return false;
  const [expires, supplied, extra] = token.split(".");
  if (!expires || !supplied || extra !== undefined || !/^\d+$/.test(expires)) return false;
  if (Number(expires) <= Math.floor(Date.now() / 1000)) return false;
  const expected = Buffer.from(signature(expires));
  const actual = Buffer.from(supplied);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export async function hasAccess() {
  const token = (await cookies()).get(COOKIE)?.value;
  return isValidAccessToken(token);
}

export function accessCookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === "true" || (process.env.COOKIE_SECURE !== "false" && process.env.NODE_ENV === "production"),
    sameSite: "lax" as const,
    path: "/",
    maxAge: ttlSeconds,
  };
}
