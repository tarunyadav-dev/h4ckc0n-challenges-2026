import { createHash, timingSafeEqual } from "node:crypto";

/** Constant-time comparison after hashing both inputs to equal-length buffers. */
export function safeEqual(a: string, b: string) {
  const left = createHash("sha256").update(a).digest();
  const right = createHash("sha256").update(b).digest();
  return timingSafeEqual(left, right);
}
