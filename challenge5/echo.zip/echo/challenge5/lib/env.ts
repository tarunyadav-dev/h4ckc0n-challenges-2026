import { z } from "zod";

const Schema = z.object({
  NODE_ENV: z.string().default("production"),
  SESSION_SECRET: z.string().min(24).refine((v) => !/^replace/i.test(v)),
  PATTERN_LOCK_SECRET: z.string().regex(/^\d{1,2}(,\d{1,2})*$/)
    .transform((s) => s.split(",").map(Number))
    .refine((a) => a.length > 0 && a.every((n) => n >= 1 && n <= 25) && new Set(a).size === a.length),
  CHALLENGE_1_SECRET: z.string().min(1).refine((v) => !/^replace/i.test(v)),
  CHALLENGE_2_SECRET: z.string().min(1).refine((v) => !/^replace/i.test(v)),
  CHALLENGE_3_SECRET: z.string().min(1).refine((v) => !/^replace/i.test(v)),
  FINAL_FLAG: z.string().min(1).refine((v) => !/^replace/i.test(v)),
  PORT: z.coerce.number().int().min(1).max(65535).default(3333),
  CHALLENGE_1_PORT: z.coerce.number().int().min(1).max(65535).default(4001),
  CHALLENGE_2_PORT: z.coerce.number().int().min(1).max(65535).default(4002),
  CHALLENGE_3_PORT: z.coerce.number().int().min(1).max(65535).default(4003),
});

export type Env = z.infer<typeof Schema>;
let cached: Env | undefined;

export function parseEnv(raw: Record<string, string | undefined>): Env {
  const result = Schema.safeParse(raw);
  if (!result.success) {
    const names = [...new Set(result.error.issues.map((issue) => issue.path.join(".")))].join(", ");
    throw new Error(`Invalid or missing environment variables: ${names}`);
  }
  return result.data;
}

export const getEnv = (): Env => (cached ??= parseEnv(process.env));
