#!/usr/bin/env python3
"""Challenge 5.3 — multi-artifact device telemetry reconstruction."""
import json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit
HERE=os.path.dirname(os.path.abspath(__file__)); PORT=int(os.environ.get('PORT','4103'))
PASSWORD='clock-skew-is-part-of-the-evidence-731'
PAGE='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Device Evidence Console</title><style>body{background:#070b16;color:#e8efff;font:16px Georgia;max-width:760px;margin:7vh auto;padding:24px}.box{border:1px solid #596b9b;border-radius:14px;padding:26px;background:#10172a}a{color:#a9caff;display:block;margin:10px 0}input,button{padding:11px;background:#0b1224;color:#fff;border:1px solid #6579ad;border-radius:6px}input{width:min(95%,500px)}small{color:#a6b2cf}.msg{min-height:1.4em;color:#ffaaaa}</style></head><body><div class="box"><h1>Device Evidence Console</h1><p>Recovered telemetry from endpoint NV-04. One credential was entered during the capture interval, but the export is incomplete without its companion records.</p><p><b>Evidence bundle</b></p><a href="/api/capture">01 — collector event export (JSON)</a><a href="/evidence/screen_trace.csv">02 — display recorder trace (CSV)</a><a href="/evidence/clock_sync.csv">03 — clock calibration (CSV)</a><a href="/evidence/process_map.csv">04 — process inventory (CSV)</a><a href="/evidence/control_map.csv">05 — control inventory (CSV)</a><a href="/evidence/keymap.csv">06 — HID usage map (CSV)</a><a href="/evidence/field-notes.txt">07 — export notes</a><hr><p><small>Recovered credential</small></p><form id="f"><input id="p" autocomplete="off" spellcheck="false" placeholder="reconstructed credential" required><button>Verify</button><div class="msg" id="m"></div></form></div><script>document.getElementById('f').onsubmit=async e=>{e.preventDefault();let m=document.getElementById('m');let r=await fetch('/api/unlock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:document.getElementById('p').value})});if(r.ok){document.open();document.write(await r.text());document.close()}else m.textContent='Credential rejected.'}</script></body></html>'''
FILES={'/evidence/screen_trace.csv':'screen_trace.csv','/evidence/clock_sync.csv':'clock_sync.csv','/evidence/process_map.csv':'process_map.csv','/evidence/control_map.csv':'control_map.csv','/evidence/keymap.csv':'keymap.csv','/evidence/field-notes.txt':'field-notes.txt'}
class H(BaseHTTPRequestHandler):
    server_version='EndpointEvidence/3.1'
    def send(self,code,body,ctype='text/html; charset=utf-8'):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        path=urlsplit(self.path).path
        if path in ('/','/index.html'): return self.send(200,PAGE.encode())
        if path=='/api/capture': return self.send(200,open(os.path.join(HERE,'capture.json'),'rb').read(),'application/json')
        if path in FILES:
            try:
                name=FILES[path]; body=open(os.path.join(HERE,name),'rb').read()
                ctype='text/plain; charset=utf-8' if name.endswith('.txt') else 'text/csv; charset=utf-8'
                return self.send(200,body,ctype)
            except OSError:return self.send(404,b'not found','text/plain')
        return self.send(404,b'not found','text/plain')
    def do_POST(self):
        if self.path!='/api/unlock':return self.send(404,b'not found','text/plain')
        n=int(self.headers.get('Content-Length','0') or 0)
        try: guess=json.loads(self.rfile.read(n).decode()).get('password','')
        except Exception: guess=''
        if guess==PASSWORD:
            try:return self.send(200,open(os.path.join(HERE,'content.html'),'rb').read())
            except OSError:return self.send(500,b'content missing','text/plain')
        return self.send(403,b'{"ok":false}','application/json')
    def log_message(self,*_):pass
if __name__=='__main__':
    print(f'Endpoint Evidence Console listening on 0.0.0.0:{PORT}'); ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
