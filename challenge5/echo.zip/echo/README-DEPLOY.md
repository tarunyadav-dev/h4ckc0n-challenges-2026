# Challenge 5 — combined deployment

One container, one public HTTP port, four internal services managed by Supervisor.

## Public routes

- Main ECHO portal: `/`
- Challenge 5.1: `/challenge5.1/`
- Challenge 5.2: `/challenge5.2/`
- Challenge 5.3: `/challenge5.3/`
- Health check: `/_health`

Only container port **8080** must be exposed by the hosting platform (CTFd).

## Build and run locally

```bash
docker build -t challenge5-combined:latest .
docker run --rm -p 8080:8080 challenge5-combined:latest
```

Or:

```bash
docker compose up --build
```

Open `http://localhost:8080/`.

## CTFd service configuration

- Service name: choose the service name required by your CTFd setup
- Image: the image you push to your registry
- Container port: `8080`
- Protocol: `HTTP`
- Do not expose the internal ports `3333`, `4101`, `4102`, or `4103`.

## Internal topology

- Next.js portal: `127.0.0.1:3333`
- Challenge 5.1: `127.0.0.1:4101`
- Challenge 5.2: `127.0.0.1:4102`
- Challenge 5.3: `127.0.0.1:4103`
- Nginx public listener: `0.0.0.0:8080`

Nginx strips each challenge prefix before forwarding, then repairs browser-visible paths, redirects, and the Challenge 5.2 cookie path. The challenge services now use the revised puzzle implementations and evidence artifacts. Nginx keeps the same public paths and internal ports.

## Environment

The portal's `challenge5/.env` is copied into `/app/.env` and explicitly sourced by the portal startup command. CTFd does not need to supply those variables separately.

**Security note:** this intentionally bundles the environment file into the image. Anyone with permission to pull/export the image or access the Docker host can recover its contents. Keep the image registry private and restrict host/registry access.

## Verification checklist

After startup:

```bash
curl -i http://localhost:8080/_health
curl -i http://localhost:8080/
curl -i http://localhost:8080/challenge5.1/
curl -i http://localhost:8080/challenge5.2/
curl -i http://localhost:8080/challenge5.3/
curl -i http://localhost:8080/challenge5.3/api/capture
```

Expected:
- Health endpoint returns `200`.
- Portal returns `200`.
- Challenge 5.1 returns its public cache page.
- Challenge 5.2 redirects `/` to `/challenge5.2/content`, then to `/challenge5.2/login` when unauthenticated.
- Challenge 5.3 returns its capture console and the capture JSON endpoint returns `200`.
