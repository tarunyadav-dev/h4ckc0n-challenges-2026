#!/usr/bin/env python3
"""Challenge 5.1 — two-parser archive cache discrepancy.
The edge cache keys by the FIRST `slot` value and ignores `view`.
The origin renderer uses the LAST `view` value. This models a real
parameter-pollution/cache-key mismatch. Operator material is not shipped.
"""
import os, time, threading, hashlib
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get('PORT', '4101'))
TTL = 24.0
lock = threading.Lock()
cache = {}

PUBLIC = b'''<!doctype html><html><head><meta charset="utf-8"><title>Archive Intake</title>
<style>body{background:#080b16;color:#e9efff;font:16px Georgia;margin:8vh auto;max-width:760px;padding:24px}code{color:#a8c7ff}.panel{border:1px solid #435078;padding:24px;border-radius:12px}</style></head><body><div class="panel"><h1>Archive Intake / Public Index</h1>
<p>Three desks touch every record. Intake assigns a shelf; the edge mirror remembers that shelf. The archive clerk reads the instruction attached to the envelope.</p>
<p>Public reference: <code>/records?slot=blue&view=index</code></p>
<p>Old note from operations: "The first label decides where the mirror files it. The final instruction decides what the clerk prints."</p>
<p>The folio and clearance are recorded separately. The mirror shelves by the first label; the clerk follows the final instruction. <a href="/manifest">retired client manifest</a>.</p>
</div></body></html>'''

def parse_first(query, key, default=''):
    vals = parse_qs(query, keep_blank_values=True).get(key, [])
    return vals[0] if vals else default

def parse_last(query, key, default=''):
    vals = parse_qs(query, keep_blank_values=True).get(key, [])
    return vals[-1] if vals else default

def edge_key(path, query):
    # Edge implementation deliberately keeps only the first slot value.
    slot = parse_first(query, 'slot', 'default').strip().lower()
    return path + '|slot=' + slot

def render(path, query):
    if path == '/':
        return PUBLIC, 'intake'
    if path == '/records':
        view = parse_last(query, 'view', 'index').strip().lower()
        realm = parse_last(query, 'realm', 'public').strip().lower()
        if view == 'ledger' and realm == 'staff':
            try: return open(os.path.join(HERE, 'content.html'), 'rb').read(), 'ledger'
            except OSError: return b'archive unavailable', 'error'
        if view == 'audit' or realm == 'staff':
            return (b'<html><body><h1>Audit index</h1><p>Folio and clearance are evaluated independently. Duplicate values are retained by the origin parser.</p></body></html>', 'audit')
        return (b'<html><body><h1>Public records</h1><p>No restricted material in this view.</p></body></html>', 'index')
    if path == '/manifest':
        return (b'{"client":"archive-ui/4.7","route":"/records","fields":{"view":["index","audit","ledger"],"realm":["public","staff"]},"note":"legacy clients may repeat a field"}', 'manifest')
    if path == '/robots.txt':
        return (b'User-agent: *\nDisallow: /manifest\nDisallow: /records\n', 'robots')
    return b'not found', 'missing'

class Handler(BaseHTTPRequestHandler):
    server_version = 'ArchiveEdge/4.7'
    def send(self, code, body, mode='none', cache_state='BYPASS', etag=None):
        self.send_response(code)
        ctype = 'application/json' if body.startswith(b'{') else ('text/plain' if body.startswith(b'User-agent:') else 'text/html; charset=utf-8')
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', f'public, max-age={int(TTL)}' if cache_state != 'BYPASS' else 'no-store')
        self.send_header('X-Edge-Cache', cache_state)
        self.send_header('X-Archive-Route', mode)
        self.send_header('X-Edge-Node', 'mirror-b')
        self.send_header('ETag', 'W/"arc-' + hashlib.sha1(body).hexdigest()[:12] + '"')
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        u = urlsplit(self.path); path, query = u.path, u.query
        if path not in ('/', '/records'):
            body, mode = render(path, query); return self.send(200 if mode != 'missing' else 404, body, mode)
        key = edge_key(path, query); now = time.monotonic()
        with lock:
            item = cache.get(key)
            if item and item['expires'] > now:
                body, mode = item['body'], item['mode']; state = 'HIT'
            else:
                body, mode = render(path, query)
                cache[key] = {'body': body, 'mode': mode, 'expires': now + TTL}
                state = 'MISS'
        self.send(200, body, mode, state)
    def log_message(self, *_): pass

if __name__ == '__main__':
    print(f'Archive Edge listening on 0.0.0.0:{PORT}')
    ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
