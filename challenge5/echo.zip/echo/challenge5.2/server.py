#!/usr/bin/env python3
"""Challenge 5.2 — versioned notebook session verifier."""
import base64, hashlib, hmac, http.cookies, os, random, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs
HERE=os.path.dirname(os.path.abspath(__file__)); PORT=int(os.environ.get('PORT','4102'))
SECRET=os.urandom(random.randint(24,48))
DOMAIN=b'ECHO/NOTEBOOK/V2\x00'
UID=iter(range(7001,9999999))

def b64e(b): return base64.urlsafe_b64encode(b).decode().rstrip('=')
def b64d(s): return base64.urlsafe_b64decode(s + '='*((4-len(s)%4)%4))
def sign(data): return hashlib.sha256(SECRET+DOMAIN+data).hexdigest()
def make_data(user):
    safe=''.join(c if c.isalnum() or c in '._-' else '_' for c in user)[:28] or 'guest'
    return (f'v=2;uid={next(UID)};usr={safe};iat={int(time.time())};nonce={os.urandom(5).hex()};scope=read;cap=0;perm=reader;fmt=claims-v2').encode()
def parse_claims(data):
    claims={}
    for part in data.split(b';'):
        if b'=' not in part: continue
        k,_,v=part.partition(b'='); claims[k]=v
    return claims
def pack(data): return b64e(data)+'~'+sign(data)
def unpack(cookie):
    try:
        left,right=cookie.split('~',1); data=b64d(left)
        if not hmac.compare_digest(sign(data),right.lower()): return None
        return data
    except Exception: return None

LOGIN='''<!doctype html><html><head><meta charset="utf-8"><title>Notebook Gateway</title><style>body{background:#080b16;color:#e9efff;font:16px Georgia;max-width:620px;margin:12vh auto;padding:24px}.box{border:1px solid #53658e;padding:28px;border-radius:12px}input,button{padding:10px;margin:8px 0;background:#111a30;color:white;border:1px solid #52638d;border-radius:6px}small{color:#9daecc}</style></head><body><div class="box"><h1>Notebook Gateway</h1><p>Temporary accounts are issued a signed wire record. The audit parser folds repeated claims in arrival order; the terminal value is authoritative.</p><form method="POST" action="/login"><label>Operator alias <input name="username" required maxlength="28"></label><button>Issue session</button></form><small>Protocol: notebook-v2 · claims are not positional.</small></div></body></html>'''
LOCKED=b'<!doctype html><html><body><h1>Notebook locked</h1><p>Session accepted as a reader. The restricted notebook requires a higher permission claim.</p></body></html>'
class H(BaseHTTPRequestHandler):
    server_version='NotebookGateway/2.4'
    def send(self,code,body,ctype='text/html; charset=utf-8',headers=()):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store')
        for k,v in headers:self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        path=self.path.split('?',1)[0]
        if path in ('/','/login'): return self.send(200,LOGIN.encode())
        if path=='/content':
            jar=http.cookies.SimpleCookie(self.headers.get('Cookie',''))
            token=jar['session'].value if 'session' in jar else ''
            data=unpack(token)
            if data is None: return self.send(303,b'',headers=[('Location','/login'),('WWW-Authenticate','Notebook realm="sealed-v2", error="invalid-record"')])
            claims=parse_claims(data)
            if claims.get(b'perm')==b'root':
                try:return self.send(200,open(os.path.join(HERE,'content.html'),'rb').read())
                except OSError:return self.send(500,b'content unavailable','text/plain')
            return self.send(403,LOCKED,headers=[('WWW-Authenticate','Notebook realm="sealed-v2", claims="scope,cap,perm"')])
        return self.send(404,b'not found','text/plain')
    def do_POST(self):
        if self.path!='/login':return self.send(404,b'not found','text/plain')
        n=int(self.headers.get('Content-Length','0') or 0); form=parse_qs(self.rfile.read(n).decode('utf-8','replace'))
        user=form.get('username',['guest'])[0]
        token=pack(make_data(user))
        return self.send(303,b'',headers=[('Location','/content'),('Set-Cookie',f'session={token}; Path=/; HttpOnly; SameSite=Lax')])
    def log_message(self,*_):pass
if __name__=='__main__':
    print(f'Notebook Gateway listening on 0.0.0.0:{PORT}'); ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
