"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ChallengeModal, type Meta } from "../modals";
import { post } from "../../lib/client";
import { buildBucky, sway, type V3 } from "../../lib/bucky";

type Ball = { i: number; ph: number; un: number; open: number; core: number; beam: number; arr: number; x: number; y: number; hx: number; hy: number; s: number; lx: number; ly: number; lr: number };
const TITLES = ["Echo! Attacking Website..", "One seal broken", "Two seals broken", "Three seals broken", "Lock is Destroyed"];
const SUBS = ["Tap a seal to read its content", "Tap another seal", "Tap another seal", "The seals are drawn together…", ""];
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const easeIn = (x: number) => x * x * x;
const easeOut = (x: number) => 1 - Math.pow(1 - x, 3);

export default function Vault({ meta, initial }: { meta: Meta[]; initial: string[] }) {
  const router = useRouter();
  const cv = useRef<HTMLCanvasElement>(null);
  const btns = useRef<(HTMLButtonElement | null)[]>([]);
  const balls = useRef<Ball[]>([]);
  const [open, setOpen] = useState<number | null>(null);
  const [done, setDone] = useState<string[]>(initial);
  const [title, setTitle] = useState(TITLES[0]);
  const [sub, setSub] = useState(SUBS[0]);
  const [flag, setFlag] = useState<string | null>(null);

  useEffect(() => {
    const c = cv.current!;
    const g = c.getContext("2d")!;
    const font = getComputedStyle(document.body).fontFamily;
    const RM = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const { A, EDGES, FACE, FC } = buildBucky();
    let W = 0, H = 0;
    const resize = () => { const d = devicePixelRatio || 1; W = innerWidth; H = innerHeight; c.width = W * d; c.height = H * d; g.setTransform(d, 0, 0, d, 0, 0); };
    addEventListener("resize", resize); resize();
    const STARS = Array.from({ length: 150 }, () => ({ x: Math.random(), y: Math.random(), r: Math.random() * 1.3 + 0.2, p: Math.random() * 6 }));

    // Restore server-confirmed progress: solved seals start unlocked.
    const B: Ball[] = meta.map((m, i) => {
      const s = initial.includes(m.id) ? 1 : 0;
      return { i, ph: i * 1.9, un: s, open: s, core: s ? 1 : 0.06, beam: s, arr: s, x: 0, y: 0, hx: 0, hy: 0, s: 0, lx: 0, ly: 0, lr: 0 };
    });
    balls.current = B;
    let phase: "play" | "collide" | "reveal" = "play";
    let wait = 0, col = 0, rev = 0, cen = 0.05, spinT = 0, last = 0, lastIdx = -1, asked = false, raf = 0;
    const k = RM ? 5 : 1; // reduced motion: same states, much shorter transitions, no spin/twinkle

    const layout = () => {
      const m = Math.min(W, H * 0.82), cx = W / 2, cy = H / 2 + 16, S = m * 0.17, D = m * 0.33;
      [-90, 30, 150].forEach((deg, i) => {
        const b = B[i], a = (deg * Math.PI) / 180, p = easeIn(clamp(col));
        b.hx = cx + D * Math.cos(a); b.hy = cy + D * Math.sin(a);
        b.x = b.hx + (cx - b.hx) * p; b.y = b.hy + (cy - b.hy) * p; b.s = S * (1 - 0.3 * p);
      });
      return { cx, cy, S, D };
    };

    const drawLock = (x: number, y: number, r: number, o: number) => {
      const col2 = `rgb(255,${(120 + 135 * o) | 0},${(110 + 145 * o) | 0})`, bw = r * 1.6, bh = r * 1.2, top = y - bh / 2 + r * 0.2;
      g.save(); g.shadowColor = col2; g.shadowBlur = 14; g.fillStyle = col2;
      g.beginPath(); g.roundRect(x - bw / 2, top, bw, bh, r * 0.2); g.fill();
      g.strokeStyle = col2; g.lineWidth = r * 0.28;
      const lift = o * r * 0.6;
      g.beginPath(); g.arc(x, top - lift, r * 0.5, Math.PI, 0);
      g.moveTo(x - r * 0.5, top - lift); g.lineTo(x - r * 0.5, top);
      if (o < 0.5) { g.moveTo(x + r * 0.5, top - lift); g.lineTo(x + r * 0.5, top); }
      g.stroke(); g.shadowBlur = 0; g.fillStyle = "#0a0d1a";
      g.beginPath(); g.arc(x, top + bh / 2, r * 0.14, 0, 7); g.fill(); g.restore();
    };

    const drawBall = (b: Ball, L: number) => {
      const yaw = Math.sin(spinT * 0.6 + b.ph) * 0.45, pit = Math.cos(spinT * 0.5 + b.ph) * 0.3;
      const P2 = A.map((v) => { const r = sway(v, yaw, pit), q = 1 / (1 - r[2] * 0.25); return [b.x + r[0] * b.s * q, b.y - r[1] * b.s * q, r[2]]; });
      g.globalCompositeOperation = "lighter";
      const R = b.s * (0.35 + 0.9 * L), gr = g.createRadialGradient(b.x, b.y, 0, b.x, b.y, R);
      gr.addColorStop(0, `rgba(255,255,255,${0.12 + 0.88 * L})`);
      gr.addColorStop(0.4, `rgba(150,190,255,${0.1 + 0.3 * L})`);
      gr.addColorStop(1, "rgba(80,120,255,0)");
      g.fillStyle = gr; g.beginPath(); g.arc(b.x, b.y, R, 0, 7); g.fill();
      g.beginPath(); FACE.forEach((f, j) => g[j ? "lineTo" : "moveTo"](P2[f][0], P2[f][1])); g.closePath();
      g.fillStyle = `rgba(${(160 + 95 * b.open) | 0},${(180 + 75 * b.open) | 0},255,${0.1 + 0.3 * b.open})`; g.fill();
      g.lineWidth = 1 + 1.2 * L;
      EDGES.forEach(([i, j]) => {
        const z = (P2[i][2] + P2[j][2]) / 2, a = 0.1 + 0.45 * (z + 1) / 2;
        g.strokeStyle = `rgba(${(140 + 115 * L) | 0},${(170 + 85 * L) | 0},255,${clamp(a + 0.4 * L)})`;
        g.beginPath(); g.moveTo(P2[i][0], P2[i][1]); g.lineTo(P2[j][0], P2[j][1]); g.stroke();
      });
      g.fillStyle = `rgba(210,225,255,${0.5 + 0.5 * L})`;
      P2.forEach((q) => { g.beginPath(); g.arc(q[0], q[1], 1.2 + (q[2] + 1) * 0.9, 0, 7); g.fill(); });
      g.globalCompositeOperation = "source-over";
      const q = sway(FC as V3, yaw, pit), kq = 1 / (1 - q[2] * 0.25);
      b.lx = b.x + q[0] * b.s * kq; b.ly = b.y - q[1] * b.s * kq; b.lr = b.s * 0.2;
      drawLock(b.lx, b.ly, b.lr, b.open);
    };

    const drawEye = (x: number, y: number, s: number, a: number) => {
      g.save(); g.globalAlpha = a; g.strokeStyle = "#fff"; g.fillStyle = "#fff"; g.shadowColor = "#9cc4ff"; g.shadowBlur = 18; g.lineWidth = 2.4;
      g.beginPath(); g.moveTo(x - s, y); g.quadraticCurveTo(x, y - s * 0.9, x + s, y); g.quadraticCurveTo(x, y + s * 0.9, x - s, y); g.stroke();
      g.beginPath(); g.arc(x, y, s * 0.34, 0, 7); g.stroke();
      g.beginPath(); g.arc(x, y, s * 0.14, 0, 7); g.fill(); g.restore();
    };

    const frame = (ms: number) => {
      const t = ms / 1000, dt = Math.min(0.05, t - last); last = t;
      spinT += RM ? 0 : dt * (1 + 9 * col);
      const { cx, cy, S, D } = layout();
      g.clearRect(0, 0, W, H);
      STARS.forEach((s) => { g.fillStyle = `rgba(200,215,255,${0.25 + (RM ? 0 : 0.35 * Math.sin(t * 1.3 + s.p))})`; g.beginPath(); g.arc(s.x * W, s.y * H, s.r, 0, 7); g.fill(); });

      B.forEach((b) => {
        b.open += (b.un - b.open) * Math.min(1, dt * 4 * k);
        b.core += ((b.un ? 1 : 0.06) - b.core) * Math.min(1, dt * 3 * k);
        if (b.un && b.core > 0.7 && b.beam < 1) b.beam = Math.min(1, b.beam + dt * 0.8 * k);
        if (b.beam >= 1) b.arr = 1;
      });
      const arr = B.reduce((s, b) => s + b.arr, 0);

      if (phase === "play" && arr === 3) { wait += dt; if (wait > 1.2 / k) { phase = "collide"; setOpen(null); } }
      if (phase === "collide") { col = Math.min(1, col + (dt * k) / 2.4); if (col >= 1) phase = "reveal"; }
      if (phase === "reveal") rev = Math.min(1, rev + (dt * k) / 3.2);
      cen += ((phase === "play" ? (arr / 3) * 0.85 + 0.05 : 1) - cen) * Math.min(1, dt * 2.5 * k);

      if (phase !== "reveal") {
        g.save(); g.setLineDash([4, 8]); g.strokeStyle = `rgba(156,196,255,${0.18 * (1 - col)})`; g.lineWidth = 1; g.beginPath();
        B.forEach((b, i) => g[i ? "lineTo" : "moveTo"](b.hx, b.hy)); g.closePath(); g.stroke(); g.restore();
      }

      g.globalCompositeOperation = "lighter";
      const cr = S * (0.4 + 1.4 * cen), cg = g.createRadialGradient(cx, cy, 0, cx, cy, cr);
      cg.addColorStop(0, `rgba(255,255,255,${0.15 + 0.85 * cen})`); cg.addColorStop(1, "rgba(120,160,255,0)");
      g.fillStyle = cg; g.beginPath(); g.arc(cx, cy, cr, 0, 7); g.fill();

      g.lineCap = "round";
      B.forEach((b) => {
        if (!b.beam || phase !== "play") return;
        const ex = b.x + (cx - b.x) * b.beam, ey = b.y + (cy - b.y) * b.beam;
        g.strokeStyle = `rgba(255,255,255,${b.arr ? 0.35 + 0.15 * Math.sin(t * 3 + b.i) : 0.55})`;
        g.lineWidth = b.arr ? 2 : 3; g.shadowColor = "#9cc4ff"; g.shadowBlur = 14;
        g.beginPath(); g.moveTo(b.x, b.y); g.lineTo(ex, ey); g.stroke(); g.shadowBlur = 0;
        if (!b.arr) { g.fillStyle = "#fff"; g.beginPath(); g.arc(ex, ey, 5, 0, 7); g.fill(); }
      });
      g.globalCompositeOperation = "source-over";

      const ballAlpha = 1 - clamp((col - 0.82) / 0.18);
      if (ballAlpha > 0) {
        g.globalAlpha = ballAlpha;
        B.forEach((b) => drawBall(b, b.core));
        g.globalAlpha = 1;
        B.forEach((b) => {
          g.fillStyle = `rgba(190,205,255,${0.75 * ballAlpha * (1 - col)})`; g.font = `${Math.max(11, S * 0.14)}px ${font}`; g.textAlign = "center";
          g.fillText(b.un ? `${meta[b.i].tag} · SOLVED` : meta[b.i].tag, b.x, b.y + b.s * 1.35);
        });
      }

      if (col > 0.85 || rev > 0) {
        const f = phase === "reveal" ? 1 - easeOut(rev * 1.6 > 1 ? 1 : rev * 1.6) : (col - 0.85) / 0.15;
        g.fillStyle = `rgba(255,255,255,${0.55 * clamp(f)})`; g.fillRect(0, 0, W, H);
        if (rev > 0) { g.strokeStyle = `rgba(255,255,255,${0.7 * (1 - rev)})`; g.lineWidth = 3; g.beginPath(); g.arc(cx, cy, easeOut(rev) * D * 2.6, 0, 7); g.stroke(); }
      }

      if (rev > 0) {
        const tri = easeOut(clamp(rev / 0.55)), eye = clamp((rev - 0.4) / 0.6);
        const T = B.map((b) => [b.hx, b.hy]);
        g.globalCompositeOperation = "lighter";
        g.strokeStyle = `rgba(200,220,255,${0.2 * eye})`; g.lineWidth = 1;
        for (let q = 0; q < 28; q++) { const a = (q * Math.PI) / 14 + t * (RM ? 0 : 0.05); g.beginPath(); g.moveTo(cx + Math.cos(a) * S * 0.7, cy + Math.sin(a) * S * 0.7); g.lineTo(cx + Math.cos(a) * D * 2.2, cy + Math.sin(a) * D * 2.2); g.stroke(); }
        const hg = g.createRadialGradient(cx, cy, 0, cx, cy, D * 1.8);
        hg.addColorStop(0, `rgba(190,215,255,${0.35 * eye})`); hg.addColorStop(1, "rgba(120,160,255,0)");
        g.fillStyle = hg; g.fillRect(0, 0, W, H); g.globalCompositeOperation = "source-over";
        g.save(); g.strokeStyle = "#fff"; g.lineWidth = 2.6; g.shadowColor = "#9cc4ff"; g.shadowBlur = 24;
        [[0, 1], [1, 2], [2, 0]].forEach(([a, c2]) => { g.beginPath(); g.moveTo(T[a][0], T[a][1]); g.lineTo(T[a][0] + (T[c2][0] - T[a][0]) * tri, T[a][1] + (T[c2][1] - T[a][1]) * tri); g.stroke(); });
        T.forEach((p) => { g.fillStyle = "#fff"; g.beginPath(); g.arc(p[0], p[1], 5 * tri, 0, 7); g.fill(); });
        g.restore();
        drawEye(cx, cy, S * 0.62, eye);
      }

      const idx = phase === "play" ? arr : phase === "collide" ? 3 : 4;
      if (idx !== lastIdx) { lastIdx = idx; setTitle(TITLES[idx]); setSub(SUBS[idx]); }

      // Centre unlocks by itself: ask the server for the flag. It refuses unless 3/3 are really verified.
      if (rev >= 1 && !asked) {
        asked = true;
        post<{ flag: string }>("/api/flag").then((r) => {
          if (r.status === 200 && r.data?.flag) setFlag(r.data.flag);
          else if (r.status === 401) router.refresh();
        });
      }

      B.forEach((b, i) => { // keyboard/touch-accessible hit targets follow the balls
        const el = btns.current[i];
        if (!el) return;
        el.style.visibility = phase === "play" ? "visible" : "hidden";
        el.style.width = el.style.height = `${b.s * 2.2}px`;
        el.style.transform = `translate(${b.x - b.s * 1.1}px,${b.y - b.s * 1.1}px)`;
      });
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); removeEventListener("resize", resize); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const active = open === null ? null : meta[open];
  return (
    <>
      <canvas ref={cv} className="cv" aria-hidden="true" />
      <div className="hud"><h1>{title}</h1><div className="sub">{sub}</div></div>
      <p className="sr" role="status" aria-live="polite">{title}. {done.length} of 3 verified.</p>
      <div className="flag" style={{ opacity: flag ? 1 : 0 }}>{flag}</div>
      {meta.map((m, i) => (
        <button key={m.id} ref={(el) => { btns.current[i] = el; }} className="seal" onClick={() => setOpen(i)}
          aria-label={`${m.title}, ${done.includes(m.id) ? "verified" : "not verified"}`} />
      ))}
      <button className="exit" onClick={async () => { await post("/api/auth/logout"); router.refresh(); }}>Exit</button>
      {active && (
        <ChallengeModal
          meta={active}
          done={done.includes(active.id)}
          onClose={() => setOpen(null)}
          onExpired={() => router.refresh()}
          onVerified={(id, completed) => {
            setDone(completed); // server-confirmed first, then the unlock animation starts
            const b = balls.current[meta.findIndex((x) => x.id === id)];
            if (b) b.un = 1;
          }}
        />
      )}
    </>
  );
}
