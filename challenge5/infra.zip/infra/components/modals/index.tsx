"use client";
import { useEffect, useId, useRef, useState } from "react";
import { post } from "../../lib/client";

export type Meta = { id: string; tag: string; title: string; desc: string; post: string; port: number };

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  const tid = useId();

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const el = ref.current!;
    const items = () => [...el.querySelectorAll<HTMLElement>("a[href],button:not([disabled]),input:not([disabled])")];
    (el.querySelector<HTMLElement>("[data-af]") ?? items()[0])?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") return e.preventDefault(), close.current();
      if (e.key !== "Tab") return;
      const l = items();
      if (!l.length) return;
      const [a, z] = [l[0], l[l.length - 1]];
      if (e.shiftKey && document.activeElement === a) e.preventDefault(), z.focus();
      else if (!e.shiftKey && document.activeElement === z) e.preventDefault(), a.focus();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      prev?.focus(); // restore focus
    };
  }, []);

  return (
    <div className="backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} className="modal" role="dialog" aria-modal="true" aria-labelledby={tid}>
        <button className="x" onClick={onClose} aria-label="Dismiss">×</button>
        <h2 id={tid}>{title}</h2>
        {children}
      </div>
    </div>
  );
}

type Status = "idle" | "pending" | "ok" | "fail" | "limited" | "error";
const FEEDBACK: Record<Status, string> = {
  idle: "",
  pending: "AUTHORIZING…",
  ok: "SYSTEM CONNECTED.",
  fail: "KEY NOT RECOGNIZED.",
  limited: "TOO MANY ATTEMPTS. WAIT BEFORE RETRYING.",
  error: "CONNECTION UNAVAILABLE. TRY AGAIN.",
};

export function ChallengeModal(p: { meta: Meta; done: boolean; onClose: () => void; onVerified: (id: string, completed: string[]) => void; onExpired: () => void }) {
  const [secret, setSecret] = useState("");
  const [st, setSt] = useState<Status>("idle");
  const [systemUrl, setSystemUrl] = useState("#");

  useEffect(() => {
    // Keep each system on the visitor's current host and protocol; only its port changes.
    const target = new URL(window.location.href);
    target.port = String(p.meta.port);
    target.pathname = "/";
    target.search = "";
    target.hash = "";
    setSystemUrl(target.toString());
  }, [p.meta.port]);
  const solved = p.done || st === "ok";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (st === "pending" || !secret) return;
    setSt("pending");
    const r = await post<{ completed: string[] }>(`/api/challenges/${p.meta.id}/verify`, { secret });
    setSecret(""); // never keep the raw value around
    if (r.status === 200 && r.data) {
      setSt("ok");
      p.onVerified(p.meta.id, r.data.completed);
    } else if (r.status === 401 && (r.data as { error?: string } | null)?.error === "unauthorized") p.onExpired();
    else setSt(r.status === 429 ? "limited" : r.status === 0 ? "error" : "fail");
  }

  return (
    <Modal title={p.meta.title} onClose={p.onClose}>
      <p>{p.meta.desc}</p>
      <p><a href={systemUrl} target="_blank" rel="noopener noreferrer">OPEN SYSTEM ↗</a></p>
      <form onSubmit={submit}>
        <label htmlFor="secret">AUTHORIZATION KEY</label>
        <div className="row">
          <input id="secret" data-af type="password" value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="off" spellCheck={false} disabled={solved} placeholder="Enter authorization key" />
          <button type="submit" disabled={st === "pending" || solved || !secret}>{st === "pending" ? "AUTHORIZE…" : "AUTHORIZE"}</button>
        </div>
      </form>
      <p role="status" className={`fb ${st}`}>{solved ? "◆ SYSTEM CONNECTED." : FEEDBACK[st]}</p>
      {solved && <section className="post"><h3>{p.meta.title} · CONNECTED</h3><p>{p.meta.post}</p></section>}
    </Modal>
  );
}
