"use client";
import { useEffect, useId, useRef, useState } from "react";
import { post } from "../../lib/client";

export type Meta = { id: string; tag: string; title: string; desc: string; url: string };
const LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose);
  close.current = onClose;
  const tid = useId();

  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const el = ref.current!;
    const items = () => [...el.querySelectorAll<HTMLElement>("a[href],button:not([disabled]),input:not([disabled])")];
    (el.querySelector<HTMLElement>("[data-af]") ?? items()[0])?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") return e.preventDefault(), close.current();
      if (e.key !== "Tab") return;
      const l = items();
      if (!l.length) return;
      const [a, z] = [l[0], l[l.length - 1]];
      if (e.shiftKey && document.activeElement === a) e.preventDefault(), z.focus();
      else if (!e.shiftKey && document.activeElement === z) e.preventDefault(), a.focus();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      prev?.focus(); // restore focus
    };
  }, []);

  return (
    <div className="backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} className="modal" role="dialog" aria-modal="true" aria-labelledby={tid}>
        <button className="x" onClick={onClose} aria-label="Close">×</button>
        <h2 id={tid}>{title}</h2>
        {children}
      </div>
    </div>
  );
}

type Status = "idle" | "pending" | "ok" | "fail" | "limited" | "error";
const FEEDBACK: Record<Status, string> = {
  idle: "",
  pending: "Verifying…",
  ok: "Verified.",
  fail: "Not accepted.",
  limited: "Too many attempts. Try again later.",
  error: "Could not reach the server. Try again.",
};

export function ChallengeModal(p: { meta: Meta; done: boolean; onClose: () => void; onVerified: (id: string, completed: string[]) => void; onExpired: () => void }) {
  const [secret, setSecret] = useState("");
  const [st, setSt] = useState<Status>("idle");
  const solved = p.done || st === "ok";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (st === "pending" || !secret) return;
    setSt("pending");
    const r = await post<{ completed: string[] }>(`/api/challenges/${p.meta.id}/verify`, { secret });
    setSecret(""); // never keep the raw value around
    if (r.status === 200 && r.data) {
      setSt("ok");
      p.onVerified(p.meta.id, r.data.completed);
    } else if (r.status === 401 && (r.data as { error?: string } | null)?.error === "unauthorized") p.onExpired();
    else setSt(r.status === 429 ? "limited" : r.status === 0 ? "error" : "fail");
  }

  return (
    <Modal title={p.meta.title} onClose={p.onClose}>
      <p>{p.meta.desc}</p>
      <p><a href={p.meta.url} target="_blank" rel="noopener noreferrer">Open challenge website ↗</a></p>
      <form onSubmit={submit}>
        <label htmlFor="secret">Secret</label>
        <div className="row">
          <input id="secret" data-af type="password" value={secret} onChange={(e) => setSecret(e.target.value)} autoComplete="off" spellCheck={false} disabled={solved} />
          <button type="submit" disabled={st === "pending" || solved || !secret}>Verify</button>
        </div>
      </form>
      <p role="status" className={`fb ${st}`}>{solved ? "◆ Verified." : FEEDBACK[st]}</p>
      {solved && <section className="post"><h3>Unlocked</h3><p>{LOREM}</p></section>}
    </Modal>
  );
}
