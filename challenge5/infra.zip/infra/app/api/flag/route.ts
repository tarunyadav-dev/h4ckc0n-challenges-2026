import { getSession } from "../../../lib/auth";
import { getEnv } from "../../../lib/env";
import { progressFor } from "../../../lib/challenges";
import { json, sameOrigin } from "../../../lib/security";

/** Reveals the flag. Server-side gate: valid session AND all three challenges verified in the DB. */
export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const s = await getSession();
  if (!s) return json(401, { ok: false, error: "unauthorized" });
  if (!(await progressFor(s.id)).all) return json(403, { ok: false, error: "locked" });
  console.info(JSON.stringify({ evt: "flag_revealed", sid: s.id, at: new Date().toISOString() }));
  return json(200, { ok: true, flag: getEnv().FINAL_FLAG });
}
