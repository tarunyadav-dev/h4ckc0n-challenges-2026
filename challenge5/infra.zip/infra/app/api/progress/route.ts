import { getSession } from "../../../lib/auth";
import { progressFor } from "../../../lib/challenges";
import { json } from "../../../lib/security";

export async function GET() {
  const s = await getSession();
  if (!s) return json(401, { ok: false, error: "unauthorized" });
  return json(200, { ok: true, ...(await progressFor(s.id)) });
}
