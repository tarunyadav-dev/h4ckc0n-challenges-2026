import { getSession } from "../../../../../lib/auth";
import { isId, progressFor, secretMatches } from "../../../../../lib/challenges";
import { prisma } from "../../../../../lib/db";
import { isLimited, json, readJson, record, sameOrigin } from "../../../../../lib/security";
import { SecretBody } from "../../../../../lib/validation";

export async function POST(req: Request, ctx: { params: Promise<{ challengeId: string }> }) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const s = await getSession();
  if (!s) return json(401, { ok: false, error: "unauthorized" });

  const { challengeId } = await ctx.params;
  if (!isId(challengeId)) return json(404, { ok: false, error: "not_found" });
  if (await isLimited("challenge", s.id)) return json(429, { ok: false, error: "rate_limited" });

  const body = SecretBody.safeParse(await readJson(req));
  if (!body.success) {
    await record("challenge", s.id, false, s.id, challengeId);
    return json(400, { ok: false, error: "invalid" });
  }
  if (!secretMatches(challengeId, body.data.secret)) {
    await record("challenge", s.id, false, s.id, challengeId);
    return json(401, { ok: false, error: "invalid" });
  }

  // Atomic + idempotent: unique(sessionId, challengeId) makes concurrent duplicates safe.
  const progress = await prisma.$transaction(async (tx) => {
    await tx.challengeCompletion.upsert({
      where: { sessionId_challengeId: { sessionId: s.id, challengeId } },
      create: { sessionId: s.id, challengeId },
      update: {},
    });
    return progressFor(s.id, tx);
  });
  await record("challenge", s.id, true, s.id, challengeId);
  return json(200, { ok: true, challengeId, ...progress });
}
