import { NextResponse } from "next/server";
import { getEnv } from "../../../../lib/env";
import { createSession, cookieOptions, getSession } from "../../../../lib/auth";
import { clientKey, isLimited, json, readJson, record, sameOrigin } from "../../../../lib/security";
import { PatternBody, patternMatches } from "../../../../lib/validation";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const key = clientKey(req);
  if (await isLimited("pattern", key)) return json(429, { ok: false, error: "rate_limited" });

  const body = PatternBody.safeParse(await readJson(req));
  if (!body.success) {
    await record("pattern", key, false);
    return json(400, { ok: false, error: "invalid" });
  }
  if (!patternMatches(body.data.pattern, getEnv().PATTERN_LOCK_SECRET)) {
    await record("pattern", key, false);
    return json(401, { ok: false, error: "invalid" });
  }

  // Anonymous player session: resume a valid one, otherwise issue a new server-generated token.
  const existing = await getSession();
  if (existing) {
    await record("pattern", key, true, existing.id);
    return json(200, { ok: true });
  }
  const { token, row } = await createSession();
  await record("pattern", key, true, row.id);
  const res = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  res.cookies.set({ ...cookieOptions(), value: token });
  return res;
}
