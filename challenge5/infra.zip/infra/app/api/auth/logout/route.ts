import { NextResponse } from "next/server";
import { COOKIE, getSession } from "../../../../lib/auth";
import { prisma } from "../../../../lib/db";
import { json, sameOrigin } from "../../../../lib/security";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return json(403, { ok: false, error: "forbidden" });
  const s = await getSession();
  if (s) await prisma.playerSession.update({ where: { id: s.id }, data: { revokedAt: new Date() } });
  const res = NextResponse.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  res.cookies.set({ name: COOKIE, value: "", path: "/", maxAge: 0 });
  return res;
}
