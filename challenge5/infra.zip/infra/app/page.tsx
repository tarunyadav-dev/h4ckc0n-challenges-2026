import PatternGate from "../components/pattern-lock/PatternGate";
import Vault from "../components/vault-interface/Vault";
import { getSession } from "../lib/auth";
import { progressFor, publicMeta } from "../lib/challenges";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) return <main className="gate"><PatternGate /></main>; // protected content is never rendered without a session
  const p = await progressFor(s.id);
  return <main><Vault meta={publicMeta()} initial={p.completed} /></main>;
}
