# API

All `POST` routes require a same-origin `Origin` header (403 otherwise), JSON bodies under 4 KB, and return `Cache-Control: no-store`. Errors are generic: `{ "ok": false, "error": "<code>" }`.

| Route | Auth | Body | Success | Failures |
|---|---|---|---|---|
| `POST /api/auth/pattern` | none | `{ "pattern": number[] }` | 200 `{ok:true}`, sets `hi_session` | 400 malformed, 401 wrong, 403 origin, 429 rate limit |
| `POST /api/auth/logout` | session optional | none | 200, session revoked, cookie cleared | 403 origin |
| `GET /api/progress` | session | none | 200 `{ok, completed:["c1"…], all, finalAvailable}` | 401 |
| `POST /api/challenges/{c1\|c2\|c3}/verify` | session | `{ "secret": string }` | 200 `{ok, challengeId, completed, all, finalAvailable}` (idempotent) | 400, 401 wrong/no session, 403, 404 unknown id, 429 |
| `POST /api/flag` | session + 3/3 | none | 200 `{ok:true, flag}` (called automatically by the UI after the final animation) | 401 no session, 403 `locked` (<3/3) or origin |

Pattern policy: 1–25 integers in 1..25, **no duplicates**, compared as an ordered list.
