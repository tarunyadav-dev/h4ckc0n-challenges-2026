# Architecture

Challenge 4 pattern → server-side validation → authenticated session → single-page infrastructure UI → three external challenge verifications → persistent completion → three 120° SVG sectors converge → central lock opens → final flag prompt and server-side validation.

**Critical distinction:** the central energy circle moves continuously for aesthetics and is not a challenge control. Only the three outer triangles are interactive challenge nodes.
