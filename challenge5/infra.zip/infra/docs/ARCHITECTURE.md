# Architecture

The visitor enters through ECHO's identity gate. The server validates the submitted pattern and creates or resumes an opaque, HttpOnly session. The authenticated page presents three independent ECHO systems. Each system opens on the visitor's current protocol and hostname, using its configured service port (`4001`, `4002`, or `4003`).

Each authorization key is submitted to ECHO's server. The server validates it against a server-only environment variable and records completion in the database. Once all three systems are connected, the animated central node converges and requests the completion flag. The flag endpoint independently verifies the session and all three database records before releasing the flag.

## Service topology

- ECHO main website: TCP `3333`
- Identity Cache: TCP `4001`
- Gold Traders: TCP `4002`
- Device Link: TCP `4003`

All services must bind to `0.0.0.0` when they need to be reached by other machines. The browser constructs each external system URL using `window.location.protocol` and `window.location.hostname`; the configured port is the only varying URL component.

The central animation is decorative. It does not authorize a system or release the flag. Server-side database state is authoritative.
