# Security notes

- **Secrets stay server-side.** Pattern, challenge secrets and flag are read from env on the server, never `NEXT_PUBLIC_`, never returned, never logged. The page, `/api/progress` and bundles contain only public metadata (ids, titles, descriptions, URLs). The flag is not in any of them. Verify with `npm run build` then `grep -r "<your secret>" .next/static`.
- **Sessions.** Anonymous player session created after the pattern gate (no accounts, by design). Token = 32 random bytes; only an HMAC-SHA256 of it is stored. Cookie: HttpOnly, SameSite=Lax, Path=/, Secure in production, TTL `SESSION_TTL_HOURS` (default 168h, absolute expiry). Logout revokes. A valid existing session is resumed on re-entry; tokens are never accepted from URLs or bodies, which prevents fixation.
- **Protected content.** `app/page.tsx` renders the vault only with a valid server session; every API checks the session itself.
- **CSRF.** `Origin` must equal `Host` on every POST, plus SameSite=Lax.
- **Progress.** Persisted in the DB via an atomic upsert on `unique(sessionId, challengeId)`; concurrent duplicates are safe. `POST /api/flag` re-checks the session and 3/3 in the database itself before returning the flag; the browser never decides. Once revealed, the flag is of course visible to that player.
- **Comparison.** SHA-256 both sides then `timingSafeEqual`.
- **Rate limits.** DB-backed sliding window per client key (pattern, hashed IP plus a global cap) or per session (challenge). Window and limits are env-configurable. Limits are approximate under heavy concurrency, and IP keys are only as trustworthy as your proxy's `X-Forwarded-For`.
- **Logging.** One JSON line per attempt: type, result, challenge id, session id. No submitted values or tokens.
- **Headers.** CSP, `nosniff`, `X-Frame-Options: DENY`, no-referrer. CSP allows `'unsafe-inline'` scripts because Next injects inline bootstrap scripts; a nonce-based CSP would be stricter.
- **Known limits.** This is a prototype, not audited. Anyone who knows the pattern can mint sessions, which is intended. Add a reverse-proxy rate limit for production.
