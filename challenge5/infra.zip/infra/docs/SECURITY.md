# Security notes

- **Secrets stay server-side.** The entry pattern, three system authorization keys, session secret, and final flag are read from server environment variables. They are never exposed through `NEXT_PUBLIC_*`, public metadata, or client bundles.
- **Environment files.** `.env.local` is deployment-specific and must never be committed or included in a public archive. `.env.example` contains placeholders only. Generate a unique `SESSION_SECRET` for each deployment.
- **Sessions.** The browser receives an opaque HttpOnly cookie. Only an HMAC of the session token is stored in the database. Sessions expire and can be revoked.
- **Same-origin requests.** State-changing API routes validate the request origin.
- **Progress.** System completion is persisted using an idempotent database upsert. The browser cannot mark a system as complete.
- **Final release.** `POST /api/flag` independently checks the session and all three database completion records before returning the final flag.
- **Rate limits.** Failed pattern and key attempts are rate-limited and recorded without logging submitted key values.
- **Transport.** Use HTTPS for the main website and all external systems. Keep `COOKIE_SECURE=true` in production.
- **Network exposure.** Expose only TCP ports `3333`, `4001`, `4002`, and `4003` as required. Do not expose the database or management interfaces.
- **Proxy trust.** Configure forwarding headers at a trusted reverse proxy. Do not blindly trust client-supplied `X-Forwarded-For`.
