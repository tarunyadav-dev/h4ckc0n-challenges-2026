# Folder structure

```text
hacker-infrastructure/
├── app/
│   ├── api/auth/pattern/route.ts
│   ├── api/challenges/[challengeId]/verify/route.ts
│   ├── api/progress/route.ts
│   ├── api/flag/route.ts
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── pattern-lock/
│   ├── vault-interface/
│   └── modals/
├── lib/
│   ├── auth/
│   ├── challenges/
│   ├── db/
│   ├── logging/
│   ├── security/
│   └── validation/
├── prisma/
├── public/references/
├── tests/e2e/
├── tests/unit/
├── docs/
├── .env.example
├── .gitignore
├── package.json
```

