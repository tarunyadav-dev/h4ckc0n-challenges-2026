import { NextResponse } from "next/server";
import { getEnv } from "./env";
import { prisma } from "./db";
import { hmac } from "./crypto";

export { hmac, safeEqual } from "./crypto";

export type AttemptType = "pattern" | "challenge";

export const json = (status: number, body: Record<string, unknown>) =>
  NextResponse.json(body, { status, headers: { "Cache-Control": "no-store" } });

/** CSRF defence for state-changing requests: Origin must match Host (plus SameSite=Lax cookie). */
export function sameOrigin(req: Request) {
  const o = req.headers.get("origin");
  const h = req.headers.get("host");
  if (!o || !h) return false;
  try {
    return new URL(o).host === h;
  } catch {
    return false;
  }
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    const t = await req.text();
    return t.length > 4096 ? undefined : JSON.parse(t);
  } catch {
    return undefined;
  }
}

export function clientKey(req: Request) {
  const ip = (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "local";
  return hmac("ip:" + ip);
}

const MAX: Record<AttemptType, () => number> = {
  pattern: () => getEnv().PATTERN_MAX_ATTEMPTS_PER_WINDOW,
  challenge: () => getEnv().CHALLENGE_MAX_ATTEMPTS_PER_WINDOW,
};

async function count(type: AttemptType, key: string) {
  const since = new Date(Date.now() - getEnv().RATE_LIMIT_WINDOW_SECONDS * 1000);
  return prisma.submissionAttempt.count({ where: { rateKey: key, type, createdAt: { gte: since } } });
}

/** DB-backed sliding window (works across instances sharing one DB). Pattern also has a global cap. */
export async function isLimited(type: AttemptType, key: string) {
  if ((await count(type, key)) >= MAX[type]()) return true;
  return type === "pattern" ? (await count(type, "global")) >= MAX[type]() * 10 : false;
}

/** Stores and logs safe metadata only: never raw secrets, flags or tokens. */
export async function record(type: AttemptType, key: string, succeeded: boolean, sessionId?: string, challengeId?: string) {
  await prisma.submissionAttempt.createMany({
    data: [
      { rateKey: key, type, succeeded, sessionId, challengeId },
      ...(type === "pattern" ? [{ rateKey: "global", type, succeeded, sessionId, challengeId }] : []),
    ],
  });
  console.info(JSON.stringify({ evt: "attempt", type, ok: succeeded, challengeId, sid: sessionId, at: new Date().toISOString() }));
}
