import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { getEnv } from "./env";

export const hmac = (s: string) => createHmac("sha256", getEnv().SESSION_SECRET).update(s).digest("hex");

/** Constant-time comparison (both sides hashed to equal length first). */
export function safeEqual(a: string, b: string) {
  const x = createHash("sha256").update(a).digest();
  const y = createHash("sha256").update(b).digest();
  return timingSafeEqual(x, y);
}
