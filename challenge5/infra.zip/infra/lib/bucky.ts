// C60 "buckyball" (truncated icosahedron) geometry, ported from the reference animation. Pure, no imports.
export type V3 = [number, number, number];
const PHI = (1 + Math.sqrt(5)) / 2;
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

/** Gentle sway: yaw (left-right) then pitch (up-down). */
export function sway(p: V3, yaw: number, pit: number): V3 {
  const x1 = p[0] * Math.cos(yaw) + p[2] * Math.sin(yaw);
  const z1 = -p[0] * Math.sin(yaw) + p[2] * Math.cos(yaw);
  return [x1, p[1] * Math.cos(pit) - z1 * Math.sin(pit), p[1] * Math.sin(pit) + z1 * Math.cos(pit)];
}

export function buildBucky() {
  const V: V3[] = [];
  const seen = new Set<string>();
  const base: V3[] = [[0, 1, 3 * PHI], [1, 2 + PHI, 2 * PHI], [PHI, 2, 2 * PHI + 1]];
  base.forEach(([a, b, c]) => {
    const cyc: V3[] = [[a, b, c], [c, a, b], [b, c, a]];
    cyc.forEach((t) => {
      for (const x of t[0] ? [1, -1] : [1]) for (const y of t[1] ? [1, -1] : [1]) for (const z of t[2] ? [1, -1] : [1]) {
        const v: V3 = [t[0] * x, t[1] * y, t[2] * z];
        const key = v.map((q) => q.toFixed(3)).join();
        if (!seen.has(key)) { seen.add(key); V.push(v); }
      }
    });
  });
  const EDGES: [number, number][] = [];
  for (let i = 0; i < V.length; i++) for (let j = i + 1; j < V.length; j++) {
    const d = Math.hypot(V[i][0] - V[j][0], V[i][1] - V[j][1], V[i][2] - V[j][2]);
    if (d > 1.95 && d < 2.05) EDGES.push([i, j]);
  }
  const NORM = Math.hypot(...V[0]);
  const U = V.map((v) => v.map((q) => q / NORM) as V3);

  // One pentagon carries the lock: rotate the ball so it points at the viewer (+z).
  const n: V3 = [0, 1, PHI];
  const nl = Math.hypot(...n);
  n[0] /= nl; n[1] /= nl; n[2] /= nl;
  const FACE = U.map((_, i) => i).sort((a, b) => dot(U[b], n) - dot(U[a], n)).slice(0, 5);
  const ax = [n[1], -n[0], 0];
  const s2 = ax[0] * ax[0] + ax[1] * ax[1];
  const kk = (1 - n[2]) / s2;
  const K = [[0, 0, ax[1]], [0, 0, -ax[0]], [-ax[1], ax[0], 0]];
  const ROT = [0, 1, 2].map((i) => [0, 1, 2].map((j) => (i === j ? 1 : 0) + K[i][j] + kk * [0, 1, 2].reduce((s, m) => s + K[i][m] * K[m][j], 0)));
  const A = U.map((v) => ROT.map((r) => dot(r as V3, v)) as V3);
  const FC = [0, 1, 2].map((i) => FACE.reduce((s, f) => s + A[f][i], 0) / 5) as V3;
  FACE.sort((a, b) => Math.atan2(A[a][1], A[a][0]) - Math.atan2(A[b][1], A[b][0]));
  return { A, EDGES, FACE, FC };
}
