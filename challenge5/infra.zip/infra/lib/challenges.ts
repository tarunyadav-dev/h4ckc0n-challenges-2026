import { getEnv, isPlaceholder } from "./env";
import { prisma } from "./db";
import { safeEqual } from "./crypto";

export const IDS = ["c1", "c2", "c3"] as const;
export type Id = (typeof IDS)[number];
export const isId = (x: string): x is Id => (IDS as readonly string[]).includes(x);

const secretOf = (id: Id) => {
  const e = getEnv();
  return { c1: e.CHALLENGE_1_SECRET, c2: e.CHALLENGE_2_SECRET, c3: e.CHALLENGE_3_SECRET }[id];
};

/** Public metadata only (no secrets). Titles are placeholders until supplied. */
export function publicMeta() {
  const e = getEnv();
  const urls = [e.CHALLENGE_1_URL, e.CHALLENGE_2_URL, e.CHALLENGE_3_URL];
  const tags = ["I", "II", "III"];
  const titles = ["Challenge I · Lorem", "Challenge II · Ipsum", "Challenge III · Dolor"];
  const descs = [
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
  ];
  return IDS.map((id, i) => ({ id, tag: tags[i], title: titles[i], desc: descs[i], url: urls[i] }));
}

/** Unconfigured (placeholder) secrets can never match: fail closed. */
export function secretMatches(id: Id, submitted: string) {
  const expected = secretOf(id);
  if (isPlaceholder(expected)) {
    safeEqual(submitted, "x");
    return false;
  }
  return safeEqual(submitted, expected);
}

type Db = Pick<typeof prisma, "challengeCompletion">;
export async function progressFor(sessionId: string, db: Db = prisma) {
  const rows = await db.challengeCompletion.findMany({ where: { sessionId } });
  const completed = IDS.filter((id) => rows.some((r) => r.challengeId === id));
  const all = completed.length === IDS.length;
  return { completed: [...completed], all, finalAvailable: all };
}
