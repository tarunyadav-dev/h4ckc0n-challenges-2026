import { getEnv, isPlaceholder } from "./env";
import { prisma } from "./db";
import { safeEqual } from "./crypto";

export const IDS = ["c1", "c2", "c3"] as const;
export type Id = (typeof IDS)[number];
export const isId = (x: string): x is Id => (IDS as readonly string[]).includes(x);

const secretOf = (id: Id) => {
  const e = getEnv();
  return { c1: e.CHALLENGE_1_SECRET, c2: e.CHALLENGE_2_SECRET, c3: e.CHALLENGE_3_SECRET }[id];
};

/** Public ECHO system metadata. Authorization values remain server-only. */
export function publicMeta() {
  const e = getEnv();
  return [
    { id: "c1" as const, tag: "01", title: "IDENTITY CACHE", desc: "The identity is already in place. I made sure of that.", post: "The record holds. Nothing out of place.", port: e.CHALLENGE_1_PORT },
    { id: "c2" as const, tag: "02", title: "NOTEBOOK", desc: "Their administrator was never as careful as he thought.", post: "Their doors are open. Just as planned.", port: e.CHALLENGE_2_PORT },
    { id: "c3" as const, tag: "03", title: "DEVICE LINK", desc: "It only takes one connection to reach everything.", post: "The connection is mine now.", port: e.CHALLENGE_3_PORT },
  ];
}

/** Unconfigured (placeholder) secrets can never match: fail closed. */
export function secretMatches(id: Id, submitted: string) {
  const expected = secretOf(id);
  if (isPlaceholder(expected)) {
    safeEqual(submitted, "x");
    return false;
  }
  return safeEqual(submitted, expected);
}

type Db = Pick<typeof prisma, "challengeCompletion">;
export async function progressFor(sessionId: string, db: Db = prisma) {
  const rows = await db.challengeCompletion.findMany({ where: { sessionId } });
  const completed = IDS.filter((id) => rows.some((r) => r.challengeId === id));
  const all = completed.length === IDS.length;
  return { completed: [...completed], all, finalAvailable: all };
}
