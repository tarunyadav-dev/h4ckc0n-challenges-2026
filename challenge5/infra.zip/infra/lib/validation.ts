import { z } from "zod";
import { safeEqual } from "./crypto";

/** Policy: 1-25 integers in 1..25, no duplicates (a dot cannot be selected twice), order matters. */
export const PatternBody = z
  .object({ pattern: z.array(z.number().int().min(1).max(25)).min(1).max(25) })
  .strict()
  .refine((b) => new Set(b.pattern).size === b.pattern.length);
export const SecretBody = z.object({ secret: z.string().min(1).max(256) }).strict();

/** Ordered comparison, never set comparison. */
export const patternMatches = (input: number[], expected: number[]) =>
  safeEqual(input.join(","), expected.join(",")) && input.length === expected.length;
