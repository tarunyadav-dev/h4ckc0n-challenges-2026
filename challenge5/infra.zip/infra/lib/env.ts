import { z } from "zod";

const placeholder = (v: string) => /^replace/i.test(v);
const Schema = z.object({
  NODE_ENV: z.string().default("development"),
  SESSION_SECRET: z.string().min(24).refine((v) => !placeholder(v), "placeholder"),
  COOKIE_SECURE: z.enum(["true", "false"]).optional(),
  SESSION_TTL_HOURS: z.coerce.number().int().min(1).max(8760).default(168),
  PATTERN_LOCK_SECRET: z
    .string()
    .regex(/^\d{1,2}(,\d{1,2})*$/)
    .transform((s) => s.split(",").map(Number))
    .refine((a) => a.length > 0 && a.every((n) => n >= 1 && n <= 25) && new Set(a).size === a.length),
  CHALLENGE_1_SECRET: z.string().min(1),
  CHALLENGE_2_SECRET: z.string().min(1),
  CHALLENGE_3_SECRET: z.string().min(1),
  FINAL_FLAG: z.string().min(1),
  PORT: z.coerce.number().int().min(1).max(65535).default(3333),
  CHALLENGE_1_PORT: z.coerce.number().int().min(1).max(65535).default(4001),
  CHALLENGE_2_PORT: z.coerce.number().int().min(1).max(65535).default(4002),
  CHALLENGE_3_PORT: z.coerce.number().int().min(1).max(65535).default(4003),
  PATTERN_MAX_ATTEMPTS_PER_WINDOW: z.coerce.number().int().min(1).default(8),
  CHALLENGE_MAX_ATTEMPTS_PER_WINDOW: z.coerce.number().int().min(1).default(10),
  RATE_LIMIT_WINDOW_SECONDS: z.coerce.number().int().min(1).default(900),
});

export type Env = z.infer<typeof Schema>;
let cached: Env | undefined;

/** Fails closed. Error text names variables only, never values. */
export function parseEnv(raw: Record<string, string | undefined>): Env {
  const r = Schema.safeParse(raw);
  if (!r.success) {
    const names = [...new Set(r.error.issues.map((i) => i.path.join(".")))].join(", ");
    throw new Error(`Invalid or missing environment variables: ${names}`);
  }
  return r.data;
}

export const getEnv = (): Env => (cached ??= parseEnv(process.env));

export const isPlaceholder = placeholder;
