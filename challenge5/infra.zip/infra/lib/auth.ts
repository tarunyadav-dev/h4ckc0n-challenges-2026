import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { getEnv } from "./env";
import { prisma } from "./db";
import { hmac } from "./crypto";

export const COOKIE = "hi_session";

export async function createSession() {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + getEnv().SESSION_TTL_HOURS * 3600_000);
  const row = await prisma.playerSession.create({ data: { tokenHash: hmac(token), expiresAt } });
  return { token, row };
}

export const cookieOptions = () => ({
  name: COOKIE,
  httpOnly: true,
  secure: (getEnv().COOKIE_SECURE ?? String(getEnv().NODE_ENV === "production")) === "true",
  sameSite: "lax" as const,
  path: "/",
  maxAge: getEnv().SESSION_TTL_HOURS * 3600,
});

/** Valid = exists, not revoked, not expired. Only a hash of the token is stored. */
export async function getSession() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token || token.length > 128) return null;
  const s = await prisma.playerSession.findUnique({ where: { tokenHash: hmac(token) } });
  return !s || s.revokedAt || s.expiresAt <= new Date() ? null : s;
}
