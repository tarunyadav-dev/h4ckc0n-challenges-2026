export async function post<T extends Record<string, unknown>>(url: string, body?: unknown): Promise<{ status: number; data: T | null }> {
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(body ?? {}),
    });
    return { status: r.status, data: (await r.json().catch(() => null)) as T | null };
  } catch {
    return { status: 0, data: null }; // offline / network failure
  }
}
