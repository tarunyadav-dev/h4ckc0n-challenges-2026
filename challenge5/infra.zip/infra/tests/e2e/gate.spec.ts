import { expect, test } from "@playwright/test";

test("protected API rejects unauthenticated access", async ({ request }) => {
  expect((await request.get("/api/progress")).status()).toBe(401);
  const r = await request.post("/api/flag", { headers: { origin: "http://localhost:3000" } });
  expect(r.status()).toBe(401);
});

test("cross-origin POST is rejected", async ({ request }) => {
  const r = await request.post("/api/auth/pattern", { data: { pattern: [1] }, headers: { origin: "http://evil.example" } });
  expect(r.status()).toBe(403);
});

test("entry gate shows the pattern lock, not the vault", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByLabel(/pattern lock/i)).toBeVisible();
  await expect(page.getByRole("button", { name: /Challenge I/ })).toHaveCount(0);
});
