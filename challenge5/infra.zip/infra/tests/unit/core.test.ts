import { describe, expect, it, vi } from "vitest";
import { buildBucky } from "../../lib/bucky";
import { parseEnv } from "../../lib/env";
import { PatternBody, patternMatches } from "../../lib/validation";
import { secretMatches } from "../../lib/challenges";

vi.mock("../../lib/db", () => ({ prisma: {} }));
Object.assign(process.env, {
  SESSION_SECRET: "x".repeat(40), PATTERN_LOCK_SECRET: "2,3,8,7,11,16,17,23,19,13",
  CHALLENGE_1_SECRET: "s1", CHALLENGE_2_SECRET: "s2", CHALLENGE_3_SECRET: "s3", FINAL_FLAG: "flag-x",
});

describe("pattern validation", () => {
  const exp = [2, 3, 8, 7, 11, 16, 17, 23, 19, 13];
  it("accepts the exact ordered sequence", () => expect(patternMatches(exp, exp)).toBe(true));
  it("rejects wrong order, missing and extra dots", () => {
    expect(patternMatches([...exp].reverse(), exp)).toBe(false);
    expect(patternMatches(exp.slice(0, 9), exp)).toBe(false);
    expect(patternMatches([...exp, 1], exp)).toBe(false);
  });
  it("rejects out-of-range, duplicate, malformed bodies", () => {
    for (const bad of [{ pattern: [0] }, { pattern: [26] }, { pattern: [1, 1] }, { pattern: [] }, { pattern: ["1"] }, { x: 1 }, null, "x"])
      expect(PatternBody.safeParse(bad).success).toBe(false);
    expect(PatternBody.safeParse({ pattern: exp }).success).toBe(true);
  });
});

describe("secrets and env", () => {
  it("each secret opens only its own challenge", () => {
    expect(secretMatches("c1", "s1")).toBe(true);
    expect(secretMatches("c1", "s2")).toBe(false);
    expect(secretMatches("c3", "s1")).toBe(false);
  });
  it("env fails closed and never echoes values", () => {
    expect(() => parseEnv({})).toThrow(/SESSION_SECRET/);
    const bad = "replace_with_a_long_random_secret";
    try { parseEnv({ ...process.env, SESSION_SECRET: bad }); } catch (e) { expect(String(e)).not.toContain(bad); }
    expect(() => parseEnv({ ...process.env, SESSION_SECRET: bad })).toThrow();
    expect(() => parseEnv({ ...process.env, PATTERN_LOCK_SECRET: "2,2,3" })).toThrow();
  });
});

describe("buckyball (C60) geometry", () => {
  const { A, EDGES, FACE, FC } = buildBucky();
  it("has 60 atoms and 90 bonds", () => { expect(A).toHaveLength(60); expect(EDGES).toHaveLength(90); });
  it("every atom sits on the unit sphere", () => A.forEach((v) => expect(Math.hypot(...v)).toBeCloseTo(1, 6)));
  it("the lock pentagon faces the viewer", () => {
    expect(FACE).toHaveLength(5);
    expect(FC[2]).toBeGreaterThan(0.8);
    FACE.forEach((f) => expect(A[f][2]).toBeCloseTo(A[FACE[0]][2], 6));
  });
});
