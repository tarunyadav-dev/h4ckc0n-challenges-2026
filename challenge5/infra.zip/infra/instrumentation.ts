export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    (await import("./lib/env")).getEnv(); // fail closed at startup
  }
}
