# ECHO — Private Network

A private, session-based ECHO website. Visitors pass the identity gate, open three independently hosted systems, submit each system's authorization key, and receive the completion flag after all three authorizations have been recorded by the server.

## Deployment layout

| Service | Port | Bind address |
|---|---:|---|
| ECHO main website | `3333` | `0.0.0.0` |
| Identity Cache | `4001` | `0.0.0.0` |
| Gold Traders | `4002` | `0.0.0.0` |
| Device Link | `4003` | `0.0.0.0` |

The three system links are built in the visitor's browser from the current page's protocol and hostname. Only the port changes; no hostname or IP address is stored in the system-link configuration. For example, a visitor opening ECHO at `https://ctf.example.org:3333` is sent to the same host over HTTPS on ports `4001`, `4002`, and `4003`. No challenge link is tied to a developer's localhost address or a fixed LAN IP.

**All four services must be reachable from the visitor's browser.** Bind each service to `0.0.0.0`, open TCP ports `3333`, `4001`, `4002`, and `4003` in the host firewall/security group, and configure TLS for every port if the main site is served over HTTPS. Do not expose internal database or administration ports.

## Requirements

- Node.js 20.9 or newer and npm
- Docker Engine and Docker Compose for the recommended deployment
- A persistent writable volume for the SQLite database
- The three external systems deployed separately on ports `4001`–`4003` (their application source is not part of this ECHO website archive)

## Configure the environment

Create the deployment environment file:

```bash
cp .env.example .env.local
openssl rand -base64 48
```

Put the generated value in `SESSION_SECRET`. Replace all `replace_...` values with the exact values configured by the challenge owner:

- `CHALLENGE_1_SECRET`
- `CHALLENGE_2_SECRET`
- `CHALLENGE_3_SECRET`
- `FINAL_FLAG`

Keep `PATTERN_LOCK_SECRET` private and synchronize it with the intended entry pattern. The three port values should remain `4001`, `4002`, and `4003` unless the external services are deliberately moved.

Never commit `.env.local`, place secrets in `NEXT_PUBLIC_*` variables, or include a populated environment file in a public release archive. The application fails closed when required values are missing or still use a `replace...` placeholder.

## Recommended production deployment (Docker)

```bash
cp .env.example .env.local
# Edit .env.local and set all deployment secrets.
docker compose up -d --build
docker compose logs -f echo
```

ECHO listens on `0.0.0.0:3333`; Docker publishes it on host port `3333`. The SQLite database and generated runtime data persist in the `echo-data` volume.

Useful operations:

```bash
docker compose ps
docker compose logs -f echo
docker compose restart echo
docker compose down
```

`docker compose down -v` also deletes the persistent database volume and all stored player progress. Do not use it for routine restarts.

## Run directly with Node.js

```bash
cp .env.example .env.local
# Edit .env.local before starting.
npm install
npm run db:deploy
npm run build
npm start
```

The app listens on port `3333` and binds to `0.0.0.0`. For local development, `npm run dev` uses the same port.

## Verification before going live

```bash
npm run typecheck
npm run lint
npm test
npx playwright install
npm run test:e2e
npm run build
```

Run these checks in the deployment environment before announcing the site. Confirm that the main site and all three external systems are reachable from a device outside the server itself, then test the full visitor flow: identity gate, each system link, each authorization key, persisted progress, and final completion.

## Production security checklist

- Serve the main website and all three systems over HTTPS.
- Keep `COOKIE_SECURE=true` in production.
- Use a unique, randomly generated `SESSION_SECRET`.
- Keep all authorization keys, the pattern, and the final flag server-side.
- Restrict database and management access; expose only the required web ports.
- Back up the persistent database volume.
- Configure your reverse proxy to preserve the original host and scheme and to set forwarding headers safely.
- If deploying multiple ECHO instances, move from local SQLite to PostgreSQL and use shared persistent storage.

## Project documentation

- `docs/ARCHITECTURE.md` — runtime flow and component responsibilities
- `docs/API.md` — private API contracts
- `docs/SECURITY.md` — session, secret, rate-limit, and deployment controls
