# Hacker Infrastructure: Next.js application

Pattern-lock entry gate, then a blue canvas scene: three rotating C60 "seals" with padlocks. Each correct secret (checked on the server) unlocks a seal and sends a light beam to the centre. When all three are server-verified the seals collide, the triangle-and-eye symbol appears, and the flag is revealed automatically (no flag prompt). The server releases the flag only to a session with 3/3 verified.

## Requirements
Node.js 20.9+ and npm (`node -v`, `npm -v`).

## Install and run
```bash
cp .env.example .env.local
openssl rand -base64 48        # paste the output into SESSION_SECRET in .env.local
npm install                    # also runs `prisma generate`
npm run db:migrate             # creates prisma/dev.db and applies migrations
npm run dev                    # http://localhost:3000
```
Edit `.env.local` first: set `SESSION_SECRET`, the three `CHALLENGE_n_SECRET` values, `FINAL_FLAG` (the text shown at the end), and the three `CHALLENGE_n_URL` links. The app **refuses to start** if required variables are missing or malformed. While a challenge secret or the flag still starts with `replace`, it can never be verified (fail closed).

Entry pattern (draw it, or type the numbers in the keyboard box): `2 3 8 7 11 16 17 23 19 13`, read from `PATTERN_LOCK_SECRET` on the server only.

`npm run dev` applies pending migrations automatically (`predev`). Prisma's CLI does not read `.env.local`, so the `db:*` scripts load it through `dotenv-cli`.

## Docker (automatic: install, build, migrate, run)
```bash
cp .env.example .env.local     # then edit challenge secrets, FINAL_FLAG, URLs
docker compose up -d --build   # http://localhost:3000
docker compose logs -f         # watch logs
docker compose down            # stop (progress is kept in the hi-data volume)
docker compose down -v         # stop AND wipe all progress
```
If `SESSION_SECRET` is left as the placeholder, the container generates one and stores it in the data volume. Serving plain http on a non-localhost address? Add `COOKIE_SECURE=false` to `.env.local`.

## Test, check, build
```bash
npm test                       # unit tests (Vitest)
npx playwright install         # once
npm run test:e2e               # end-to-end (starts the dev server)
npm run typecheck && npm run lint
npm run db:deploy && npm run build && npm start
```

## Production notes
- Use PostgreSQL (change `provider` in `prisma/schema.prisma` and `DATABASE_URL`, then regenerate the migration) for multiple instances, serverless, or ephemeral disks. SQLite file storage is single-machine only.
- Serve over HTTPS (cookie is `Secure` when `NODE_ENV=production`) and behind a proxy that sets a trustworthy `X-Forwarded-For`.
- Docs: `docs/ARCHITECTURE.md`, `docs/API.md`, `docs/SECURITY.md`.
