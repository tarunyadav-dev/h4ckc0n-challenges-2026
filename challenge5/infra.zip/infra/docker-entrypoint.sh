#!/bin/sh
set -e
umask 077
mkdir -p /data

# No SESSION_SECRET supplied? Generate one once and keep it in the data volume,
# so sessions survive restarts.
case "${SESSION_SECRET:-replace}" in
  replace*)
    [ -f /data/.session_secret ] || node -e "process.stdout.write(require('crypto').randomBytes(48).toString('base64'))" > /data/.session_secret
    SESSION_SECRET="$(cat /data/.session_secret)"
    export SESSION_SECRET
    ;;
esac

# Apply database migrations, then start the app.
node_modules/.bin/prisma migrate deploy
exec node_modules/.bin/next start -H 0.0.0.0 -p "${PORT:-3333}"
