-- CreateTable
CREATE TABLE "PlayerSession" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "tokenHash" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" DATETIME NOT NULL,
    "lastSeenAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "revokedAt" DATETIME
);

-- CreateTable
CREATE TABLE "ChallengeCompletion" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sessionId" TEXT NOT NULL,
    "challengeId" TEXT NOT NULL,
    "verifiedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ChallengeCompletion_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES "PlayerSession" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "SubmissionAttempt" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "sessionId" TEXT,
    "rateKey" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "challengeId" TEXT,
    "succeeded" BOOLEAN NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- CreateIndex
CREATE UNIQUE INDEX "PlayerSession_tokenHash_key" ON "PlayerSession"("tokenHash");

-- CreateIndex
CREATE UNIQUE INDEX "ChallengeCompletion_sessionId_challengeId_key" ON "ChallengeCompletion"("sessionId", "challengeId");

-- CreateIndex
CREATE INDEX "SubmissionAttempt_rateKey_type_createdAt_idx" ON "SubmissionAttempt"("rateKey", "type", "createdAt");
