import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "tests/e2e",
  use: { baseURL: "http://127.0.0.1:3333" },
  webServer: { command: "npm run dev", url: "http://127.0.0.1:3333", reuseExistingServer: true, timeout: 120_000 },
});
