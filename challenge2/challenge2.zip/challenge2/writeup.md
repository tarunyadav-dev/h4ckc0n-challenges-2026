# NOVAVAULT — THE MIRROR INVESTIGATION
## Challenge 2: Digital Footprints
### Player Walkthrough

---

## 1. Finding the transaction

I begin by checking the available commands and transaction records.

```text
help
protocol
transactions
```

The incident concerns ₹50 crore disappearing from NovaVault. I look for the settled transfer from `NOVAVAULT-COLD` to `BRIDGE-7`.

The most relevant candidates are `TX881`, `TX1114`, `TX1117`, and `TX1118`.

I compare their transaction details instead of selecting one based only on the amount.

- `TX1117` is excluded because it originates from `SETTLEMENT-POOL` and has a held tranche.
- `TX1114` has the same displayed amount, time, source, and destination, but belongs to a different ledger batch and settlement reference. Its session `S1075` is also from the previous day and already closed.
- `TX1118` belongs to the same batch family, but it is a later commit at 03:14:39 and references the closed session `S1311`.

The remaining transaction is:

**`TX881`**

```text
transactions TX881
```

It records the settled ₹500,000,000 transfer at 03:14:07.

I have found the financial transaction under investigation.

## 2. Following the session

I inspect the transaction's associated session.

```text
sessions S704
```

The transaction points to session `S704`, which was active from 03:11:42 to 03:18:09 on 12 September.

The session is associated with `A.MEHRA` (Arjun Mehra).

However, its metadata indicates:
- Cached gateway ticket.
- Degraded MFA.
- Unverified operator binding.

I check the ticket evidence before accepting the identity attribution.

```text
inspect EV54035
```

The record shows:

- Expected device fingerprint: `am0417lap221`
- Presented device fingerprint: `a704cafe9912`

Arjun's personnel record lists `am0417lap221` as his usual device fingerprint.

The presented fingerprint does not match.

**Conclusion:** The session carries Arjun's identity, but the device mismatch and unverified operator binding mean I cannot establish that Arjun personally operated it.

## 3. Following the access event

The session references `EV0315`.

```text
inspect EV0315
```

This event records an access claim for room `R12`, submitted through `gateway-cache`.

However, there are three important details:

- Badge: `UNKNOWN`
- Nonce: `MISSING`
- Signature scope: `gateway-transport`

The event links session `S704` to room `R12`, but it does not independently establish a valid physical access by Arjun.

I follow the room reference.

```text
rooms R12
locker L09
```

`R12` is the Cold Storage Corridor. Its locker records include `L09`.

The locker summary provides:

```text
ROOM          R12
CUSTODIAN     EMP041
LAST OPEN     03:12:58
SEAL          intact
OPEN EVENT    EV0309
CUSTODY BLOCK CB-12B
```

I now have the locker and custody-block references needed for the investigation.

## 4. Verifying the original reader event

I return to `EV0315` and examine its reader information.

It contains:

- Reader: `RD12`
- Room: `R12`
- Device counter: `45346`
- Frame digest: `e786fdcf91be6fa7`

I look for the original reader record using these matching attributes.

```text
events R12
inspect EV0762
```

The record `EV0762` contains:

```text
TYPE           DOOR
SOURCE         reader-RD12
ROOM           R12
BADGE          BD417
INTEGRITY      signed
SEQUENCE       RD12-882
NONCE          NONCE-EV0762-A
WORK ORDER     WO-N03-076
DEVICE COUNTER 45346
FRAME DIGEST   e786fdcf91be6fa7
TIME           03:11:04
```

The device counter and frame digest match `EV0315`.

However, `EV0762` is an original signed reader event with a valid badge and nonce, whereas `EV0315` is a gateway claim with missing authentication fields.

This distinction is important:

- `EV0315` connects `S704` to `R12`.
- `EV0762` establishes the original signed reader access at `R12`.

The gateway claim appears to reuse the original reader attributes while attaching them to Arjun's session.

## 5. Identifying the physical access trail

The original reader event provides badge `BD417`.

I follow this badge through the signed door records.

```text
events BD417
```

The relevant events form the following sequence:

| Time | Event | Room |
|---|---|---|
| 03:06:10 | `EV0761` | R08 |
| 03:11:04 | `EV0762` | R12 |
| 03:16:32 | `EV0763` | R17 |
| 03:21:18 | `EV0764` | R23 |

All four records use badge `BD417` and work order `WO-N03-076`.

I verify the badge ownership.

```text
inspect EV0776
people EMP076
```

The active badge `BD417` belongs to `EMP076` (Ira Rao), a facilities technician.

**Conclusion:** The signed reader records establish a physical route associated with `BD417` and `EMP076`. They do not establish that this person operated the financial transaction.

## 6. Investigating locker L09

The locker summary lists `EV0309` as its opening event, but I need to verify the actual physical condition.

```text
events L09
```

Two records are particularly important.

**Actuator diagnostic — `EV0774`**

```text
inspect EV0774
```

The signed diagnostic records:

- Locker: `L09`
- Latch cause: `SVC-BYPASS`
- Command origin: `MC-2`
- Key sensed: `false`
- Nonce: `NONCE-EV0762-A`
- Badge: `BD417`

The matching nonce connects this diagnostic to the signed reader event `EV0762`.

The diagnostic also warns that its session field comes from the controller cache, so I do not treat that session attribution as proof of the human operator.

**Seal inspection — `EV0775`**

```text
inspect EV0775
```

The signed inspection records a 4 mm lift on the locker seal.

This contradicts the locker summary's `intact` status.

**Conclusion:** L09 experienced a service-bypass latch operation without a key being sensed, and its seal was physically lifted.

## 7. Connecting the maintenance console and custody post

The actuator diagnostic identifies maintenance console `MC-2`.

I check its associated session.

```text
sessions
```

The relevant session is `S0705`, associated with `ECHO.SVC`, using source IP `10.76.3.90`.

I compare this with the network-flow record for `S704`.

```text
inspect EV57511
```

The S704 tunnel endpoint is also `10.76.3.90`.

This connects the financial session's network path with the maintenance-console session.

The camera record provides additional corroboration:

```text
inspect EV52423
```

It records a camera gap in R12 from 03:11:10 to 03:13:40, associated with the maintenance-console path.

Finally, I resolve the locker custody reference.

The locker belongs to custody block `CB-12B`. Its general custodian is `EMP041`, but the incident occurred during the N-03 night shift.

I inspect the signed roster allocation.

```text
events CB-12B
```

The important allocation is `EV50137`:

```text
CUSTODY BLOCK  CB-12B
POST           OPS203
OPERATOR       EMP076
ROSTER         N-03/17
INTEGRITY      signed
```

The roster snapshot `EV0772` confirms the same night-shift assignment.

The distinction is:

- `EMP041`: General/legacy custodian.
- `EMP076`: Operator assigned during the relevant night shift.
- `OPS203`: Custody post assigned to block `CB-12B`.

**Conclusion:** The required custody reference is `OPS203`, not an employee ID.

---

## 8. Final submission

All six components are now supported by the investigation.

| Position | Value | Reason |
|---|---|---|
| 1 | `TX881` | Settled ₹50 crore transaction |
| 2 | `S704` | Session linked to the transaction |
| 3 | `EV315` | Gateway access claim attached to S704 |
| 4 | `R12` | Room identified by the access claim |
| 5 | `L09` | Locker associated with the room and custody block |
| 6 | `OPS203` | Signed custody post allocation |

**Important formatting detail:** The original event ID is `EV0315`, but the submission convention removes the leading zero and requires `EV315`.

I submit:

```text
submit TX881-S704-EV315-R12-L09-OPS203
```

The console accepts the submission and returns:

**Flag**

```text
d4rk{the_identity_was_real_the_attribution_was_not}
```



---

## Final Investigation Conclusion

The ₹50 crore transfer was committed under session `S704`, which carried Arjun Mehra's identity. However, the device fingerprint mismatch and unverified operator binding undermine the attribution.

The gateway access claim `EV0315` attached room `R12` to that session, but its reader attributes match the original signed event `EV0762`, which records badge `BD417`.

The signed physical-access records associate that badge with `EMP076`. The locker diagnostic and seal inspection establish a service-bypass operation on `L09`, while the network-flow and camera records connect the maintenance-console path to the financial session.

The signed custody allocation identifies `OPS203` as the post assigned to the locker's custody block.

The evidence supports a manipulated identity-attribution trail and a maintenance-console-related physical access path. It does not prove that Arjun personally operated the transfer or that EMP076 personally authorised the financial movement.

**The central finding: the identity recorded in a session can be real, while the attribution of the activity to that identity can still be false.**