"""NovaVault console command modules."""
