"""Evidence submission and case status."""
from commands.core import Command

def submit(s,args):
    usage="Usage: submit <TX>-<S>-<EV>-<R>-<L>-<OPS>"
    if len(args)!=1:
        s.send(usage); s.send("Use help submit for the identifier order."); return
    parts=args[0].split("-")
    if len(parts)!=6 or any(not p for p in parts):
        s.send("Rejected: provide exactly six identifiers in the required order."); return
    txid,sid,evid,rid,lid,opsid=parts
    w=s.world
    get=lambda collection,ident: next((r for r in w[collection] if r.get("id","").upper()==ident.upper()),None)
    tx=get("transactions",txid); sess=get("sessions",sid); event=get("events",evid)
    room=get("rooms",rid); locker=get("lockers",lid); cust=get("identities",opsid)
    if not all((tx,sess,event,room,locker,cust)):
        s.send("Rejected: at least one identifier does not exist in the relevant register."); return
    # Validate evidence through the records' own fields, not a separate relationship graph.
    valid=(tx.get("session","").upper()==sid.upper()
      and sess.get("event_ref","").upper()==evid.upper()
      and event.get("target","").upper()==rid.upper()
      and room.get("locker","").upper()==lid.upper()
      and locker.get("custodian","").upper()==opsid.upper())
    if not valid:
        s.send("Rejected: these records do not form a supported investigation chain.")
        s.send("Re-check the reference fields in each record; matching timestamps alone are insufficient.")
        return
    if args[0].upper()!=s.credentials["secret_key"].upper():
        s.send("Chain is structurally consistent, but it does not match the incident finding expected by the case file.")
        return
    s.solved=True
    for line in s.credentials.get("after_submit",[]): s.send(line)
    s.send(s.credentials["flag"])

def case(s,args):
    s.send("CASE STATUS: "+("ACCEPTED" if s.solved else "OPEN"))
COMMANDS={"submit":Command(submit,"Submit the six-part evidence chain","submit <TX>-<S>-<EV>-<R>-<L>-<OPS>"),
 "case":Command(case,"Check whether the investigation has been accepted","case")}
