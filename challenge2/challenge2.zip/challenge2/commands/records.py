
"""Database-style identifier-based record browser."""

from commands.core import Command
import textwrap
import json
from collections import Counter


COLLECTIONS = {
    "people": ("identities", "IDENTITY REGISTER"),
    "sessions": ("sessions", "SESSION INDEX"),
    "transactions": ("transactions", "SETTLEMENT LEDGER"),
    "events": ("events", "EVENT ARCHIVE"),
    "rooms": ("rooms", "FACILITY DIRECTORY"),
    "lockers": ("lockers", "CUSTODY REGISTER"),
}

TERMINAL_WIDTH = 100
MAX_COLUMN_WIDTH = 28
MIN_COLUMN_WIDTH = 9


# =========================================================
# VALUE FORMATTING
# =========================================================

def format_value(key, value):
    """Format values consistently for terminal display."""

    if value is None:
        return "N/A"

    if isinstance(value, bool):
        return "YES" if value else "NO"

    if isinstance(value, int):
        if "amount" in key.lower():
            return f"INR {value:,}"
        return f"{value:,}"

    if isinstance(value, float):
        return f"{value:,.2f}"

    if isinstance(value, (list, dict)):
        if not value:
            return "None"

        return json.dumps(
            value,
            ensure_ascii=False,
            separators=(",", ":")
        )

    return str(value)


# =========================================================
# COMPACT TRANSACTION PARTS
# =========================================================

def compact_amount_parts(parts):
    """
    Create a compact summary of transaction tranches.

    All original tranche data remains available through:
        amount <transaction-id>

    This function only changes how amount_parts appears
    in the main transactions table.
    """

    if not parts:
        return "No tranches"

    total = sum(
        int(part.get("amount_inr", 0))
        for part in parts
    )

    statuses = Counter(
        str(part.get("status", "UNKNOWN"))
        for part in parts
    )

    status_summary = ", ".join(
        f"{status}: {count}"
        for status, count in statuses.items()
    )

    return (
        f"{len(parts)} parts | "
        f"INR {total:,} | "
        f"{status_summary}"
    )


# =========================================================
# TABLE RENDERER
# =========================================================

def render_table(s, title, headers, rows):
    """
    Render multiple records in one aligned ASCII table.

    Features:
    - Dynamic column widths
    - Text wrapping
    - Long-value handling
    - Consistent separators
    """

    if not headers:
        return

    headers = [
        str(header).upper().replace("_", " ")
        for header in headers
    ]

    rows = [
        [str(value) for value in row]
        for row in rows
    ]

    column_count = len(headers)

    if not rows:
        s.send("")
        s.send(title)
        s.send("No records found.")
        return

    # Validate rows.
    if any(len(row) != column_count for row in rows):
        s.send("[ERROR] Invalid table structure.")
        return

    # Determine available width.
    available_width = max(
        TERMINAL_WIDTH - (3 * column_count) - 1,
        column_count * MIN_COLUMN_WIDTH
    )

    # Calculate ideal widths.
    widths = []

    for i in range(column_count):
        longest = max(
            len(headers[i]),
            *(len(row[i]) for row in rows)
        )

        widths.append(
            min(
                max(longest, MIN_COLUMN_WIDTH),
                MAX_COLUMN_WIDTH
            )
        )

    # Shrink columns when the table is too wide.
    while sum(widths) > available_width:

        candidates = [
            i for i in range(column_count)
            if widths[i] > MIN_COLUMN_WIDTH
        ]

        if not candidates:
            break

        # Shrink the widest column first.
        widest = max(candidates, key=lambda i: widths[i])
        widths[widest] -= 1

    # Construct table border.
    border = (
        "+"
        + "+".join("-" * (width + 2) for width in widths)
        + "+"
    )

    def print_row(row):
        """Print a row with wrapped cells."""

        wrapped_cells = []

        for i, value in enumerate(row):

            lines = textwrap.wrap(
                value,
                width=widths[i],
                break_long_words=True,
                break_on_hyphens=False
            )

            wrapped_cells.append(lines or [""])

        max_lines = max(
            len(cell) for cell in wrapped_cells
        )

        for line_index in range(max_lines):

            output = []

            for i, cell in enumerate(wrapped_cells):

                value = (
                    cell[line_index]
                    if line_index < len(cell)
                    else ""
                )

                output.append(value.ljust(widths[i]))

            s.send("| " + " | ".join(output) + " |")

    # Print table.
    s.send("")
    s.send("=" * min(TERMINAL_WIDTH, len(border)))
    s.send(f" {title}")
    s.send(border)

    print_row(headers)

    s.send(border)

    for row in rows:
        print_row(row)

    s.send(border)


# =========================================================
# COLLECTION TABLE
# =========================================================

def emit(s, kind, identifier=None):

    if kind not in COLLECTIONS:
        s.send(
            "Unknown record type. Available: "
            + ", ".join(COLLECTIONS)
        )
        return

    key, title = COLLECTIONS[kind]

    all_records = s.world.get(key, [])

    # Filter records if an identifier was supplied.
    if identifier:

        target = identifier.upper()

        records = [
            record for record in all_records
            if str(record.get("id", "")).upper() == target
        ]

    else:
        # No identifier means display EVERY record.
        records = all_records

    if not records:
        s.send("")
        s.send("[!] No matching records found.")
        return

    # Collect every field present in the selected records.
    # This handles fields that exist only in certain records.
    headers = []

    for record in records:
        for field in record:

            if field not in headers:
                headers.append(field)

    # Move ID to the first column.
    if "id" in headers:
        headers.remove("id")
        headers.insert(0, "id")

    # Build table rows.
    table_rows = []

    for record in records:

        row = []

        for field in headers:

            value = record.get(field)

            # SPECIAL CONDITION:
            # Compact amount_parts ONLY in transactions.
            if kind == "transactions" and field == "amount_parts":
                formatted = compact_amount_parts(value or [])

            else:
                formatted = format_value(field, value)

            row.append(formatted)

        table_rows.append(row)

    # Display all matching records in ONE table.
    heading = (
        f"{title} — {identifier.upper()}"
        if identifier
        else title
    )

    s.send("")
    s.send(f"TOTAL RECORDS: {len(records)}")

    render_table(
        s,
        heading,
        headers,
        table_rows
    )

    # Explain the compact field only for transactions.
    if kind == "transactions":
        s.send("")
        s.send(
            "AMOUNT PARTS: Compact summary of transaction tranches."
        )
        s.send(
            "Use 'amount <transaction-id>' for the complete breakdown."
        )


# =========================================================
# COLLECTION COMMAND HANDLERS
# =========================================================

def make(kind):

    def handler(s, args):

        if len(args) > 1:
            s.send(f"Usage: {kind} [identifier]")
            return

        emit(
            s,
            kind,
            args[0] if args else None
        )

    return handler


# =========================================================
# INSPECT COMMAND
# =========================================================

def inspect(s, args):

    if len(args) != 1:
        s.send("Usage: inspect <identifier>")
        return

    identifier = args[0].upper()

    for kind, (key, _) in COLLECTIONS.items():

        records = s.world.get(key, [])

        if any(
            str(record.get("id", "")).upper() == identifier
            for record in records
        ):

            emit(s, kind, identifier)
            return

    s.send("")
    s.send(f"[!] Identifier {identifier} not found.")
    s.send("Use 'list' to browse available collections.")


# =========================================================
# LIST COMMAND
# =========================================================

def list_cmd(s, args):

    if len(args) > 1:
        s.send("Usage: list [collection]")
        return

    if args:
        emit(s, args[0].lower())
        return

    rows = []

    for kind, (key, title) in COLLECTIONS.items():

        rows.append([
            kind,
            len(s.world.get(key, [])),
            title
        ])

    render_table(
        s,
        "AVAILABLE RECORD COLLECTIONS",
        ["COLLECTION", "RECORD COUNT", "DESCRIPTION"],
        rows
    )

    s.send("")
    s.send("Usage: <collection> [identifier]")
    s.send("Example: transactions TX881")


# =========================================================
# TRANSACTION AMOUNT RECONCILIATION
# =========================================================

def amount(s, args):

    if len(args) != 1:
        s.send("Usage: amount <transaction-id>")
        return

    tx_id = args[0].upper()

    tx = next(
        (
            record
            for record in s.world.get("transactions", [])
            if str(record.get("id", "")).upper() == tx_id
        ),
        None
    )

    if not tx:
        s.send("[!] Transaction not found.")
        return

    parts = tx.get("amount_parts", [])

    if not parts:

        total = int(tx.get("amount_inr", 0))

        s.send(f"TRANSACTION: {tx_id}")
        s.send(f"TOTAL: INR {total:,}")
        return

    rows = []

    for part in parts:

        rows.append([
            part.get("part_id", "N/A"),
            f"INR {int(part.get('amount_inr', 0)):,}",
            part.get("status", "N/A"),
            part.get("time", "N/A"),
            part.get("reference", "N/A")
        ])

    total = sum(
        int(part.get("amount_inr", 0))
        for part in parts
    )

    render_table(
        s,
        f"TRANSACTION RECONCILIATION — {tx_id}",
        ["PART ID", "AMOUNT", "STATUS", "TIME", "REFERENCE"],
        rows
    )

    s.send("")
    s.send(f"RECONCILED TOTAL: INR {total:,}")
    s.send("Compare against the parent ledger entry.")
    s.send("Do not count parent and tranches twice.")


# =========================================================
# COMMAND REGISTRY
# =========================================================

COMMANDS = {
    "list": Command(
        list_cmd,
        "List record collections or display all records",
        "list [collection]"
    ),

    "inspect": Command(
        inspect,
        "Find and display a record by identifier",
        "inspect <identifier>"
    ),

    "amount": Command(
        amount,
        "Reconcile transaction amount tranches",
        "amount <transaction-id>"
    )
}


for _kind in COLLECTIONS:

    COMMANDS[_kind] = Command(
        make(_kind),
        f"Display {_kind} records in a table",
        f"{_kind} [identifier]"
    )
