
"""Console orientation, command reference, and investigation utilities."""

from dataclasses import dataclass


# =========================================================
# COMMAND STRUCTURE
# =========================================================

@dataclass
class Command:
    handler: object
    description: str
    usage: str

    def __call__(self, session, args):
        return self.handler(session, args)


# =========================================================
# HELP COMMAND
# =========================================================

def help_cmd(s, args):

    if args:

        name = args[0].lower()
        command = s.commands.get(name)

        if not command:
            s.send(f"No help entry for '{name}'. Use help.")
            return

        s.send("")
        s.send(f"{name.upper()} — {command.description}")
        s.send("Usage: " + command.usage)

        if name == "inspect":
            s.send(
                "Provide an exact record identifier. "
                "Example: inspect TX881 or inspect EV315."
            )

        elif name == "amount":
            s.send(
                "Displays the individual transaction tranches "
                "and calculates their reconciled total."
            )

        elif name == "submit":
            s.send(
                "Expected identifier order: "
                "transaction-session-event-room-locker-custodian."
            )

        elif name == "list":
            s.send(
                "Available collections: people, sessions, "
                "transactions, events, rooms, lockers."
            )

        elif name == "clear":
            s.send(
                "Clears the visible terminal screen. "
                "It does not delete records or investigation history."
            )

        elif name in (
            "people",
            "sessions",
            "transactions",
            "events",
            "rooms",
            "lockers"
        ):
            s.send(
                f"Use '{name}' to display all records, or "
                f"'{name} <identifier>' to display one matching record."
            )

        return

    s.send("")
    s.send("=" * 65)
    s.send("NOVAVAULT INVESTIGATION CONSOLE — COMMAND REFERENCE")
    s.send("=" * 65)

    for name, command in sorted(s.commands.items()):

        s.send(
            f"  {name:<14} "
            f"{command.description}"
        )
        s.send(
            f"  {'':14} Usage: {command.usage}"
        )

    s.send("-" * 65)
    s.send("SUGGESTED START")
    s.send("  1. protocol")
    s.send("  2. infra")
    s.send("  3. catalog")
    s.send("  4. list")
    s.send("")
    s.send(
        "This is a simulated forensic evidence console, "
        "not an operating-system shell."
    )


# =========================================================
# EXIT COMMAND
# =========================================================

def quit_cmd(s, args):

    if args:
        s.send("Usage: exit")
        return

    s.send("Closing investigation session.")
    s.running = False


# =========================================================
# CLEAR COMMAND
# =========================================================

def clear_cmd(s, args):

    if args:
        s.send("Usage: clear")
        return

    # ANSI escape sequences:
    # ESC[2J  -> Clear the entire screen
    # ESC[H   -> Move cursor to the top-left corner
    s.send("\033[2J\033[H")


# =========================================================
# PROTOCOL COMMAND
# =========================================================

def protocol_cmd(s, args):

    if args:
        s.send("Usage: protocol")
        return

    s.send("")
    s.send("=" * 65)
    s.send("NOVAVAULT INVESTIGATION CONSOLE / PROTOCOL 4.2")
    s.send("=" * 65)

    s.send("INTERFACE")
    s.send(
        "Read-only forensic interface. Commands retrieve and "
        "display stored records; they do not modify evidence."
    )

    s.send("")
    s.send("IDENTIFIER CONVENTIONS")
    s.send("  TX...   Settlement transaction")
    s.send("  S...    Authentication session")
    s.send("  EV...   Archived system event")
    s.send("  R...    Facility room")
    s.send("  L...    Custody locker")
    s.send("  OPS...  Custody operator")

    s.send("")
    s.send("EVIDENCE HANDLING")
    s.send(
        "Records may contain references to other identifiers. "
        "Follow those references and inspect the corresponding records."
    )
    s.send(
        "Compare timestamps, source systems, and evidence quality. "
        "A matching identifier does not establish causation."
    )
    s.send(
        "An authenticated session establishes an authenticated "
        "context. It does not independently identify the human "
        "who operated the terminal."
    )

    s.send("")
    s.send("INVESTIGATION PRINCIPLE")
    s.send(
        "Distinguish recorded facts, system-generated associations, "
        "and conclusions that still require independent verification."
    )


# =========================================================
# CATALOG COMMAND
# =========================================================

def catalog_cmd(s, args):

    items = {
        "people": (
            "Identity register containing employee identities, "
            "service accounts, and custody operators."
        ),

        "sessions": (
            "Authentication records containing session identifiers, "
            "associated identities, login details, terminal or gateway "
            "information, and recorded authentication status."
        ),

        "transactions": (
            "Settlement ledger containing transaction identifiers, "
            "transfer details, associated references, and amount "
            "breakdowns where available."
        ),

        "events": (
            "Archived system observations. Records may include event "
            "source, target identifier, timestamp, and evidence metadata."
        ),

        "rooms": (
            "Facility directory containing room identifiers and "
            "available location, zone, reader, or locker information."
        ),

        "lockers": (
            "Custody records containing locker identifiers, location "
            "details, assigned operators, and recorded seal or "
            "opening information."
        )
    }

    s.send("")
    s.send("=" * 65)
    s.send("RECORD CATALOG")
    s.send("=" * 65)

    if args:

        key = args[0].lower()

        if key not in items:
            s.send(
                "Unknown catalog type. Choose: "
                + ", ".join(items)
            )
            return

        s.send(key.upper())
        s.send(items[key])
        return

    for key, description in items.items():
        s.send("")
        s.send(f"{key.upper()}")
        s.send(f"  {description}")


# =========================================================
# INFRASTRUCTURE COMMAND
# =========================================================

def infra_cmd(s, args):

    if args:
        s.send("Usage: infra")
        return

    s.send("")
    s.send("=" * 70)
    s.send("NOVAVAULT INFRASTRUCTURE")
    s.send("SYSTEM ARCHITECTURE AND EVIDENCE FLOW")
    s.send("=" * 70)

    # -----------------------------------------------------
    # 1. AUTHENTICATION SERVICE
    # -----------------------------------------------------

    s.send("")
    s.send("[01] AUTHENTICATION SERVICE")

    s.send(
        "The authentication service validates credentials "
        "and maintains authenticated sessions."
    )

    s.send(
        "Session records use identifiers beginning with S. "
        "They associate an authenticated identity with a recorded "
        "login context."
    )

    s.send(
        "A session record can establish which identity was associated "
        "with a login. It cannot, by itself, prove who physically "
        "operated the device."
    )

    # -----------------------------------------------------
    # 2. NETWORK AND GATEWAY INFRASTRUCTURE
    # -----------------------------------------------------

    s.send("")
    s.send("[02] NETWORK AND GATEWAY INFRASTRUCTURE")

    s.send(
        "Gateway and VPN systems record network access information, "
        "including available terminal, route, and session references."
    )

    s.send(
        "Some archived gateway observations may be cached or replayed. "
        "Check the event's source and whether the original device "
        "verification material is present."
    )

    s.send(
        "A gateway record associated with a session is not necessarily "
        "independent proof of the person using that session."
    )

    # -----------------------------------------------------
    # 3. SETTLEMENT LEDGER
    # -----------------------------------------------------

    s.send("")
    s.send("[03] SETTLEMENT LEDGER")

    s.send(
        "The settlement ledger records financial transfers. "
        "Transaction identifiers begin with TX."
    )

    s.send(
        "A transaction may contain multiple amount tranches. "
        "The parent ledger entry and its component tranches describe "
        "the same transfer and must not be counted twice."
    )

    s.send(
        "Use the amount command to inspect the tranche breakdown "
        "and calculate its reconciled total."
    )

    # -----------------------------------------------------
    # 4. EVENT ARCHIVE
    # -----------------------------------------------------

    s.send("")
    s.send("[04] EVENT ARCHIVE")

    s.send(
        "The event archive stores observations generated by "
        "different system components. Event identifiers begin with EV."
    )

    s.send(
        "An event may reference a transaction, session, gateway, "
        "facility location, or another recorded object."
    )

    s.send(
        "The source of an event matters. A ledger entry, an access "
        "reader observation, and a cached gateway record do not "
        "necessarily provide the same level of evidence."
    )

    s.send(
        "Check timestamps, target identifiers, source information, "
        "and verification metadata before treating an event as proof."
    )

    # -----------------------------------------------------
    # 5. FACILITY DIRECTORY
    # -----------------------------------------------------

    s.send("")
    s.send("[05] FACILITY DIRECTORY")

    s.send(
        "The facility directory describes physical locations "
        "inside the NovaVault facility."
    )

    s.send(
        "Room identifiers begin with R. A room record may contain "
        "its name, zone, access reader, and associated locker."
    )

    s.send(
        "Resolve a room identifier using its actual record. "
        "Do not infer a location from an event timestamp alone."
    )

    # -----------------------------------------------------
    # 6. CUSTODY REGISTER
    # -----------------------------------------------------

    s.send("")
    s.send("[06] CUSTODY REGISTER")

    s.send(
        "The custody register contains locker records. "
        "Locker identifiers begin with L."
    )

    s.send(
        "A locker record may identify its physical location, "
        "assigned custodian, seal state, and recorded opening details."
    )

    s.send(
        "Custody operator identifiers begin with OPS."
    )

    s.send(
        "An assigned custodian is not automatically the person "
        "who physically opened or accessed a locker."
    )

    # -----------------------------------------------------
    # INVESTIGATION WORKFLOW
    # -----------------------------------------------------

    s.send("")
    s.send("=" * 70)
    s.send("INVESTIGATION WORKFLOW")
    s.send("=" * 70)

    s.send("")
    s.send("[STEP 1] ESTABLISH THE FINANCIAL RECORD")

    s.send(
        "Identify the relevant transaction. Inspect its ledger entry "
        "and reconcile its amount tranches."
    )

    s.send("")
    s.send("[STEP 2] TRACE THE AUTHENTICATED SESSION")

    s.send(
        "Read the session reference associated with the transaction. "
        "Inspect the session and identify the recorded identity."
    )

    s.send("")
    s.send("[STEP 3] VERIFY THE EVENT EVIDENCE")

    s.send(
        "Follow the event reference associated with the session. "
        "Inspect its source, target, timestamp, and verification status."
    )

    s.send("")
    s.send("[STEP 4] RESOLVE THE PHYSICAL LOCATION")

    s.send(
        "If the relevant event references a room, inspect that room "
        "record to determine its actual location and associated locker."
    )

    s.send("")
    s.send("[STEP 5] EXAMINE CUSTODY INFORMATION")

    s.send(
        "Inspect the referenced locker. Identify its assigned custodian "
        "and compare assignment information with recorded access evidence."
    )

    s.send("")
    s.send("[STEP 6] RECONCILE THE EVIDENCE")

    s.send(
        "Compare the transaction, session, event, room, locker, "
        "and custody records. Verify that every identifier is supported "
        "by the records you inspected."
    )

    # -----------------------------------------------------
    # EVIDENCE CAUTION
    # -----------------------------------------------------

    s.send("")
    s.send("=" * 70)
    s.send("EVIDENCE CAUTION")
    s.send("=" * 70)

    s.send(
        "The archive contains records from multiple systems and "
        "multiple periods of activity."
    )

    s.send(
        "Similar timestamps, shared locations, and matching identities "
        "can create misleading associations."
    )

    s.send(
        "Do not treat proximity as proof, assignment as physical access, "
        "or authentication as human attribution."
    )

    s.send(
        "Build the conclusion from identifier references, provenance, "
        "and independently supported observations."
    )


# =========================================================
# COMMAND REGISTRY
# =========================================================

COMMANDS = {

    "help": Command(
        help_cmd,
        "Show available commands or command-specific help",
        "help [command]"
    ),

    "protocol": Command(
        protocol_cmd,
        "Explain console rules and identifier conventions",
        "protocol"
    ),

    "exit": Command(
        quit_cmd,
        "Close the current investigation session",
        "exit"
    ),

    "clear": Command(
        clear_cmd,
        "Clear the visible terminal screen",
        "clear"
    ),

    "catalog": Command(
        catalog_cmd,
        "Explain available evidence collections",
        "catalog [type]"
    ),

    "infra": Command(
        infra_cmd,
        "Explain system architecture and the evidence investigation workflow",
        "infra"
    ),
}
