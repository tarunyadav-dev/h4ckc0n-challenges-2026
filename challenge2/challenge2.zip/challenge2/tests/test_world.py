"""Integrity tests for the identifier-driven NovaVault challenge."""
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
class ChallengeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.w=json.loads((ROOT/"data/world.json").read_text())
    def by_id(self,collection,ident):
        return next(x for x in self.w[collection] if x["id"]==ident)
    def test_no_relationship_graph_collection(self):
        self.assertNotIn("links",self.w)
        self.assertFalse(any(k in self.w for k in ("relations","edges")))
    def test_unique_ids(self):
        for name,rows in self.w.items():
            if rows and isinstance(rows,list) and isinstance(rows[0],dict) and "id" in rows[0]:
                ids=[x["id"] for x in rows]
                self.assertEqual(len(ids),len(set(ids)),name)
    def test_amount_parts_sum_to_fifty_crore(self):
        tx=self.by_id("transactions","TX881")
        self.assertEqual(sum(p["amount_inr"] for p in tx["amount_parts"]),500_000_000)
        self.assertEqual(tx["amount_inr"],500_000_000)
    def test_submission_chain_uses_record_fields(self):
        tx=self.by_id("transactions","TX881")
        se=self.by_id("sessions",tx["session"])
        ev=self.by_id("events",se["event_ref"])
        room=self.by_id("rooms",ev["target"])
        locker=self.by_id("lockers",room["locker"])
        cust=self.by_id("identities",locker["custodian"])
        self.assertEqual([tx["id"],se["id"],ev["id"],room["id"],locker["id"],cust["id"]],
                         ["TX881","S704","EV315","R12","L09","OPS203"])
    def test_cache_record_is_not_verified_reader_proof(self):
        ev=self.by_id("events","EV315")
        self.assertEqual(ev["source"],"gateway-cache")
        self.assertIn("signature",ev["detail"])
        self.assertIn("absent",ev["detail"])
    def test_flag_not_in_public_world(self):
        self.assertNotIn("d4rk{",json.dumps(self.w))
    def test_removed_commands_are_not_registered(self):
        import sys
        sys.path.insert(0,str(ROOT))
        from command_registry import load_commands
        cmds=load_commands()
        for removed in ("relations","query","trace","reconcile","topology","custody","ledger","chronicle"):
            self.assertNotIn(removed,cmds)
        for needed in ("help","catalog","infra","list","inspect","amount","submit","case","exit","quit"):
            self.assertIn(needed,cmds)
if __name__=="__main__": unittest.main()
