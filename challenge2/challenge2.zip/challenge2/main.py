"""NovaVault Challenge 2: stdio evidence console, one process per socat connection."""
import json
import os
import shlex
import sys
from pathlib import Path

from command_registry import load_commands

ROOT = Path(__file__).resolve().parent


def load_json(path):
    with (ROOT / path).open(encoding="utf-8") as handle:
        return json.load(handle)


def required_env(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Required environment variable is missing: {name}")
    return value


def load_credentials():
    """Secrets are injected at runtime; never read from a shipped JSON file."""
    after_submit_raw = os.environ.get("NOVAVAULT_AFTER_SUBMIT_JSON", "[]")
    try:
        after_submit = json.loads(after_submit_raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("NOVAVAULT_AFTER_SUBMIT_JSON must be valid JSON") from exc
    if not isinstance(after_submit, list) or not all(isinstance(x, str) for x in after_submit):
        raise RuntimeError("NOVAVAULT_AFTER_SUBMIT_JSON must be a JSON array of strings")
    return {
        "username": required_env("NOVAVAULT_USERNAME"),
        "password": required_env("NOVAVAULT_PASSWORD"),
        "secret_key": required_env("NOVAVAULT_SUBMISSION_KEY"),
        "flag": required_env("NOVAVAULT_FLAG"),
        "after_submit": after_submit,
    }


CONFIG = load_json("config.json")
WORLD = load_json("data/world.json")
COMMANDS = load_commands()


class Session:
    """Per-connection stdio session. socat creates a fresh process for each client."""

    def __init__(self):
        self.world = WORLD
        self.credentials = CREDENTIALS
        self.commands = COMMANDS
        self.solved = False
        self.running = True
        self.max_line_bytes = int(CONFIG.get("max_line_bytes", 4096))

    def send(self, message=""):
        sys.stdout.write(str(message) + "\r\n")
        sys.stdout.flush()

    def read_line(self, prompt=""):
        if prompt:
            sys.stdout.write(prompt)
            sys.stdout.flush()
        raw = sys.stdin.buffer.readline(self.max_line_bytes + 1)
        if not raw:
            self.running = False
            raise EOFError
        if len(raw) > self.max_line_bytes and not raw.endswith(b"\n"):
            # Drain the remainder of an oversized line before continuing.
            while raw and not raw.endswith(b"\n"):
                raw = sys.stdin.buffer.readline(self.max_line_bytes + 1)
            self.send("Input rejected: line too long.")
            return ""
        return raw.decode("utf-8", errors="replace").strip()

    def authenticate(self):
        banner = ROOT / "banner.txt"
        if banner.exists():
            self.send(banner.read_text(encoding="utf-8").rstrip())
        self.send("=" * 58)
        self.send("SECURE SESSION INITIALIZATION")
        self.send("Authentication required.")
        self.send("=" * 58)
        username = self.read_line("username: ")
        password = self.read_line("password: ")
        if username != self.credentials["username"] or password != self.credentials["password"]:
            self.send("[!] ACCESS DENIED")
            return False
        self.send("[+] ACCESS GRANTED")
        self.orientation()
        return True

    def orientation(self):
        """Interactive briefing: each Enter reveals one operational concept."""
        pages = [
            ("WELCOME, INVESTIGATOR",
             "You are entering the NovaVault incident archive. A transfer of funds occurred at 03:14. Your task is to reconstruct what the records can prove. Do not decide who is responsible from the first name you see."),
            ("HOW THIS CONSOLE WORKS",
             "This is a simulated read-only evidence terminal, not Windows, Linux, or a network shell. Type only the commands shown by help. Press Enter after each command. Use exit or quit when you are finished."),
            ("THE IDENTIFIER SYSTEM",
             "Every record has an identifier. TX means transaction, S means authentication session, EV means event, R means room, L means locker, and OPS means a custody operator. An identifier printed inside one record is a lead to inspect elsewhere."),
            ("THE INFRASTRUCTURE",
             "Credentials are checked by the authentication service, which creates sessions. The gateway records network and terminal context. The settlement ledger records money movement. Independent systems emit events. The facility directory maps rooms to lockers, and the custody register records assignments."),
            ("HOW TO READ EVIDENCE",
             "A ledger can prove that a transfer was recorded under a session. A session can show which account authenticated. Neither alone proves which human was physically operating the terminal. Event source and missing original proof matter."),
            ("YOUR INVESTIGATION LOOP",
             "Start with list transactions. Use inspect <ID> to open a record. Follow identifiers printed in its fields. Use amount <TX-ID> when a transfer contains tranches. Compare competing records; timestamps close together are not automatically causation."),
            ("WHAT YOU MUST ESTABLISH",
             "Your final submission contains six identifiers: the incident transaction, its session, the session's key event, the event's room, that room's locker, and the locker’s assigned custodian. The console will validate whether the records support your chain. This briefing does not tell you which identifiers are correct."),
            ("FIELD NOTE",
             "Keep a small evidence table while investigating: identifier, source system, timestamp, what it proves, and what it does not prove. A plausible story is not the same as a supported conclusion.")
        ]
        self.send("")
        self.send("KABIR SHARMA — INVESTIGATION BRIEFING")
        self.send("Press ENTER to reveal each briefing section. Type nothing else here.")
        for title, body in pages:
            answer = self.read_line("[ENTER] ")
            if answer is None:
                return
            self.send("")
            self.send("=== " + title + " ===")
            self.send(body)
        self.send("")
        self.send("[BRIEFING COMPLETE] Kabir: The archive is yours. Begin with 'help' or 'list transactions'.")

    def run(self):
        try:
            if not self.authenticate():
                return
            while self.running:
                try:
                    raw = self.read_line(CONFIG.get("prompt", "RPUB:NovaVault> "))
                except EOFError:
                    break
                if not raw:
                    continue
                try:
                    parts = shlex.split(raw)
                except ValueError:
                    self.send("Syntax error. Check quotation marks. Use help query for examples.")
                    continue
                if not parts:
                    continue
                name, args = parts[0].lower(), parts[1:]
                command = self.commands.get(name)
                if command is None:
                    self.send(f"Unknown operation '{name}'. This is not an OS shell; try help.")
                    continue
                try:
                    command(self, args)
                except Exception as exc:
                    print(f"Command error: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
                    self.send("Operation failed. Internal error recorded.")
        except (EOFError, BrokenPipeError, OSError):
            return


try:
    CREDENTIALS = load_credentials()
except Exception as exc:
    print(f"Startup configuration error: {exc}", file=sys.stderr, flush=True)
    raise SystemExit(1)


if __name__ == "__main__":
    Session().run()
