"""Load command modules automatically, while rejecting duplicate command names."""
import importlib
import pkgutil
import commands


def load_commands():
    registry = {}
    for info in pkgutil.iter_modules(commands.__path__):
        module = importlib.import_module(f"commands.{info.name}")
        for name, handler in getattr(module, "COMMANDS", {}).items():
            if name in registry:
                raise ValueError(f"Duplicate command: {name}")
            registry[name] = handler
    return registry
