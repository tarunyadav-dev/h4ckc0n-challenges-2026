# NovaVault Terminal (Challenge2)

Standalone TCP challenge service. The application listens on port 4444 through `socat`.

## Included configuration

The `.env` file is bundled in this package and loaded by `main.py` using Python's standard library.
Environment variables supplied by the runtime override values in the bundled `.env`.

**Security:** Bundling `.env` embeds its values in the Docker image. Anyone who can pull or inspect the image may recover them. Use challenge-only credentials/secrets and do not reuse personal or production credentials. If the image is accessible to participants, consider moving secrets to a supported runtime environment-variable mechanism instead.

## Build and run locally

Run from this directory:

```powershell
docker compose up -d --build
docker compose ps
```

Connect:

```powershell
ncat localhost 4444
```

Stop:

```powershell
docker compose down
```

## Build and push to CTFd

```powershell
docker build --platform linux/amd64 -t novavault-terminal:latest .
docker login -u "tarun@h4ckc0n.ctfd.io" registry.ctfd.io
docker tag novavault-terminal:latest registry.ctfd.io/h4ckc0n/novavault-terminal
docker push registry.ctfd.io/h4ckc0n/novavault-terminal
```

In CTFd, configure the container image as:

`registry.ctfd.io/h4ckc0n/novavault-terminal`

Configure its TCP service to expose container port `4444`.


## Windows Docker Desktop troubleshooting

If Docker reports that `dockerDesktopLinuxEngine` is missing or returns HTTP 500
on `/_ping`, the Docker Engine is unavailable. This is a Docker Desktop/WSL2
problem, not an application build error. Start Docker Desktop and wait until
its engine is running before building. If it remains unhealthy, run
`wsl --shutdown` in an elevated PowerShell, reopen Docker Desktop, and verify
`docker version` shows both Client and Server sections. Do not run `docker
system prune`, reset Docker to factory defaults, or delete volumes during a
live CTF.

This Compose file targets `linux/amd64`, matching the CTFd container platform.
