"""Evidence submission and case status."""
from commands.core import Command


def submit(s, args):
    usage = "Usage: submit <TX>-<S>-<EV>-<R>-<L>-<OPS>"
    if len(args) != 1:
        s.send(usage)
        s.send("Use help submit for the identifier order.")
        return

    parts = args[0].split("-")
    if len(parts) != 6 or any(not p for p in parts):
        s.send("Rejected: provide exactly six identifiers in the required order.")
        return

    txid, sid, evid, rid, lid, opsid = parts
    w = s.world

    def canonical_id(value):
        value = str(value).upper()
        split_at = len(value)
        while split_at > 0 and value[split_at - 1].isdigit():
            split_at -= 1
        prefix, digits = value[:split_at], value[split_at:]
        if prefix and digits:
            return prefix + str(int(digits))
        return value

    def get(collection, ident):
        wanted = canonical_id(ident)
        return next(
            (record for record in w.get(collection, [])
             if canonical_id(record.get("id", "")) == wanted),
            None,
        )

    tx = get("transactions", txid)
    sess = get("sessions", sid)
    event = get("events", evid)
    room = get("rooms", rid)
    locker = get("lockers", lid)
    allocation = get("identities", opsid)

    if not all((tx, sess, event, room, locker, allocation)):
        s.send("Rejected: at least one identifier does not exist in the relevant register.")
        return

    # The settlement event and the room-access event are distinct records
    # emitted under the same authenticated session.
    ledger_event = get("events", tx.get("event_ref", ""))

    transaction_supported = (
        tx.get("session", "").upper() == sid.upper()
        and sess.get("event_ref", "").upper() == tx.get("event_ref", "").upper()
        and ledger_event is not None
        and ledger_event.get("session", "").upper() == sid.upper()
        and ledger_event.get("target", "").upper() == txid.upper()
    )

    access_supported = (
        event.get("session", "").upper() == sid.upper()
        and event.get("target", "").upper() == rid.upper()
    )

    room_locker_supported = (
        locker.get("room", "").upper() == rid.upper()
        and (
            room.get("locker", "").upper() == lid.upper()
            or any(str(x).upper() == lid.upper()
                   for x in room.get("lockers", []))
        )
    )

    # OPS identifiers are roster allocation/post records. Resolve the
    # locker's custody block to its signed allocation and verify the staffed
    # operator against the locker's shift assignment for that roster revision.
    roster_allocation = next(
        (
            record for record in w.get("events", [])
            if record.get("type") == "ROSTER_ALLOC"
            and record.get("custody_block") == locker.get("custody_block")
            and record.get("target") == locker.get("custody_block")
            and record.get("post", "").upper() == opsid.upper()
            and record.get("integrity") == "signed"
        ),
        None,
    )

    staffing_supported = False
    if roster_allocation:
        staffing_supported = any(
            assignment.get("roster_revision") == roster_allocation.get("roster_revision")
            and assignment.get("operator") == roster_allocation.get("operator")
            for assignment in locker.get("shift_assignments", [])
        )

    custody_supported = (
        allocation.get("record_class") == "allocation"
        and allocation.get("role") == "custody allocation"
        and bool(locker.get("custody_block"))
        and staffing_supported
    )

    if not all((
        transaction_supported,
        access_supported,
        room_locker_supported,
        custody_supported,
    )):
        s.send("Rejected: these records do not form a supported investigation chain.")
        s.send("Re-check the reference fields in each record; matching timestamps alone are insufficient.")
        return

    # Keep the configured submission secret unchanged.
    if args[0].upper() != s.credentials["secret_key"].upper():
        s.send("Chain is structurally consistent, but it does not match the incident finding expected by the case file.")
        return

    s.solved = True
    for line in s.credentials.get("after_submit", []):
        s.send(line)
    s.send(s.credentials["flag"])


def case(s, args):
    s.send("CASE STATUS: " + ("ACCEPTED" if s.solved else "OPEN"))


COMMANDS = {
    "submit": Command(
        submit,
        "Submit the six-part evidence chain",
        "submit <TX>-<S>-<EV>-<R>-<L>-<OPS>",
    ),
    "case": Command(case, "Check whether the investigation has been accepted", "case"),
}
